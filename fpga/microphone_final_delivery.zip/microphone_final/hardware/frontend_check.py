"""Ideal small-signal calculations, not SPICE or bench validation."""
from pathlib import Path
import json
import numpy as np
import os
HERE=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(HERE.parent/'pc/.mplconfig')
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt

# Each stage: IN-R1-A-R2-B, Cg B->GND, Cf A->OUT, unity follower B->OUT.
sections=[(8660.,10e-9,10.68e-9),(6190.,10e-9,20e-9),(2370.,10e-9,150e-9)]
f=np.geomspace(10,40000,2000)
s=2j*np.pi*f

def response(r1,r2,cg,cf):
    return 1/(1+s*cg*(r1+r2)+s*s*r1*r2*cg*cf)

h=np.ones_like(s)
details=[]
for r,cg,cf in sections:
    h*=response(r,r,cg,cf)
    details.append(dict(R1= r,R2=r,Cg=cg,Cf=cf,
                        f0_hz=1/(2*np.pi*r*np.sqrt(cg*cf)),Q=.5*np.sqrt(cf/cg)))
# Final divider Rtop=4.99k, Rbottom=1k, 100k bleed after switch, 10nF.
# Approximation omits switch/series/board100 ohm for AC plot (documented).
bottom=1/(1/1000+1/100000)
ratio=bottom/(4990+bottom)
rt=4990*bottom/(4990+bottom)
h*=1/(1+s*rt*10e-9)
normal=20*np.log10(np.abs(h))
test_f=(440,1000,1800,4000,6200,8000)
attenuation={str(hz):float(np.interp(np.log(hz),np.log(f),normal)) for hz in test_f}
# Guaranteed DC bounding calculation intentionally ignores bleed load (larger voltage).
rmax=(1000*1.001)/(4990*.999+1000*1.001)
rmin=(1000*.999)/(4990*1.001+1000*.999)
assert 5.5*rmax<.95
rng=np.random.default_rng(441)
curves=[]
for _ in range(500):
    mc=np.ones_like(s)
    for r,cg,cf in sections:
        r1,r2=r*(1+rng.uniform(-.001,.001,2))
        g,fb=np.array([cg,cf])*(1+rng.uniform(-.01,.01,2))
        mc*=response(r1,r2,g,fb)
    mc*=1/(1+s*rt*10e-9)
    curves.append(20*np.log10(np.abs(mc)))
curves=np.asarray(curves)
fig,ax=plt.subplots(figsize=(9,4.5),layout='constrained')
ax.semilogx(f,normal,label='Nominal ideal filter, DC normalized')
ax.fill_between(f,curves.min(axis=0),curves.max(axis=0),alpha=.2,label='500 draws: R +/-0.1%, C +/-1%')
ax.axvline(4000,color='r',linestyle='--',label='8 kS/s Nyquist 4 kHz')
ax.set(xlabel='Frequency (Hz)',ylabel='Gain relative to DC (dB)',ylim=(-100,3),xlim=(100,40000),title='Proposed analog front end: calculation only, not measured')
ax.grid(True,which='both',alpha=.25);ax.legend();fig.savefig(HERE/'filter_response.png')
result=dict(scope='Ideal small-signal analytic calculation and tolerance sampling only; no SPICE or physical measurement',
            sections=details,attenuation_db_relative_to_dc=attenuation,
            divider_ratio_nominal_with_100k_bleed=ratio,
            divider_ratio_worst_case_without_bleed=rmax,
            normal_3v3_quiet_bias_volts=1.65*ratio,
            normal_3v3_plus5pct_max_volts=3.465*rmax,
            bounded_5v5_upstream_max_volts=5.5*rmax,
            supply_limit_assumption='All upstream active outputs stay between 0 and 5.5 V. Not a single-fault/surge guarantee.',
            tolerance_draws=500,passed=True)
(HERE/'calculations.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
