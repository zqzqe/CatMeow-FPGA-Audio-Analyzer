set root [file dirname [file dirname [file normalize [info script]]]]
set project_dir [file join $root vivado microphone_audio]
if {[file exists [file join $project_dir microphone_audio.xpr]]} {
    open_project [file join $project_dir microphone_audio.xpr]
} else {
    create_project microphone_audio $project_dir -part xc7a75tfgg484-2
}
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]
set_param general.maxThreads 2
if {[llength [get_ips -quiet xadc_wiz_mic]] == 0} {
    create_ip -name xadc_wiz -vendor xilinx.com -library ip -version 3.3 -module_name xadc_wiz_mic
}
set_property -dict [list CONFIG.INTERFACE_SELECTION {ENABLE_DRP} \
    CONFIG.DCLK_FREQUENCY {50} CONFIG.ADC_CONVERSION_RATE {500} \
    CONFIG.TIMING_MODE {Event} CONFIG.STARTUP_CHANNEL_SELECTION {single_channel} \
    CONFIG.SINGLE_CHANNEL_SELECTION {VAUXP15_VAUXN15} CONFIG.SEQUENCER_MODE {Off} \
    CONFIG.CHANNEL_AVERAGING {None} CONFIG.ENABLE_CONVST {true}] [get_ips xadc_wiz_mic]
generate_target all [get_ips xadc_wiz_mic]
report_property [get_ips xadc_wiz_mic] -file [file join $root reports xadc_ip_properties.txt]
puts "MIC_IP_GENERATION_PASS"
close_project
exit
