param([string]$Script = 'create_project.tcl', [string[]]$TclArgs = @())
$ErrorActionPreference = 'Stop'
$here = Split-Path $PSScriptRoot -Parent
$workspace = Split-Path (Split-Path $here -Parent) -Parent
$scratch = Join-Path $workspace 'work\microphone_final'
New-Item -ItemType Directory -Force $scratch | Out-Null
$savedEnv = @{}
foreach ($name in @('TEMP','TMP','APPDATA','LOCALAPPDATA','XILINX_LOCAL_USER_DATA')) {
    $savedEnv[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
}
$env:TEMP = $scratch
$env:TMP = $scratch
$env:APPDATA = Join-Path $scratch 'appdata'
$env:LOCALAPPDATA = Join-Path $scratch 'localappdata'
$env:XILINX_LOCAL_USER_DATA = 'no'
New-Item -ItemType Directory -Force $env:APPDATA,$env:LOCALAPPDATA | Out-Null
Push-Location $scratch
try {
    $tag = [IO.Path]::GetFileNameWithoutExtension($Script)
    $invokeArgs = @('-mode','batch','-source',(Join-Path $PSScriptRoot $Script),'-log',(Join-Path $here "reports\$tag.log"),'-journal',(Join-Path $here "reports\$tag.jou"))
    if ($TclArgs.Count -gt 0) { $invokeArgs += @('-tclargs') + $TclArgs }
    & 'D:\2025.2\Vivado\bin\vivado.bat' @invokeArgs
    if ($LASTEXITCODE -ne 0) { throw "Vivado $Script failed" }
    if ((Get-Content -Raw (Join-Path $here "reports\$tag.log")) -match '(?m)^ERROR:') { throw "Vivado reported errors" }
} finally {
    Pop-Location
    foreach ($name in $savedEnv.Keys) {
        [Environment]::SetEnvironmentVariable($name, $savedEnv[$name], 'Process')
    }
}
