"""Check concrete saved evidence without rebuilding or programming hardware."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parents[1]
RPT=ROOT/'reports'
before=json.loads((RPT/'protected_originals_baseline.json').read_text(encoding='utf-8'))
changed=[name for name,digest in before.items() if not Path(name).is_file() or hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest]
log=(RPT/'build_impl.log').read_text(encoding='utf-8',errors='replace')
timing=(RPT/'timing_routed.rpt').read_text()
start=timing.index('WNS(ns)')
numbers=re.search(r'\n\s+([+-]?\d+\.\d+)\s+([+-]?\d+\.\d+)\s+\d+\s+\d+\s+([+-]?\d+\.\d+)\s+([+-]?\d+\.\d+)',timing[start:])
wns,tns,whs,ths=map(float,numbers.groups())
route=(RPT/'route_status.rpt').read_text()
drc=(RPT/'drc_routed.rpt').read_text()
drc_rules=re.findall(r'\|\s*([A-Z0-9_-]+)\s*\|\s*(Warning|Critical Warning|Error)\s*\|',drc)
xpr=ET.parse(ROOT/'vivado/microphone_audio/microphone_audio.xpr')
options={e.attrib.get('Name'):e.attrib.get('Val') for e in xpr.findall('.//Configuration/Option')}
simulation=xpr.find(".//FileSet[@Name='sim_1']")
tb_excluded=True
for file in simulation.findall('File'):
    if file.attrib['Path'].endswith('.sv'):
        used=[e.attrib['Val'] for e in file.findall(".//Attr[@Name='UsedIn']")]
        tb_excluded &= used==['simulation']
new_sources={}
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in ('.v','.sv','.xci','.xdc','.py','.tcl','.ps1','.bat') and '__pycache__' not in p.parts:
        new_sources[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(RPT/'validated_sources.json').write_text(json.dumps(new_sources,indent=2),encoding='utf-8')
end_to_end=json.loads((RPT/'python_end_to_end.json').read_text(encoding='utf-8'))
checks=dict(original_files_unchanged=not changed,
            synth_and_implementation_markers='MIC_SYNTH_PASS' in log and 'MIC_IMPLEMENTATION_PASS' in log,
            no_build_errors=not re.search(r'^ERROR:|^CRITICAL WARNING:',log,re.M),
            routed_timing_pass=wns>=0 and whs>=0 and tns==ths==0,
            no_routing_errors=bool(re.search(r'nets with routing errors\.+\s*:\s*0',route)),
            only_documented_cfg_warning=drc_rules==[('CFGBVS-1','Warning')],
            correct_part=options.get('Part')=='xc7a75tfgg484-2',
            testbenches_simulation_only=bool(tb_excluded),
            no_bitstreams=not list(ROOT.rglob('*.bit')),
            uart_exact_original_copy=(ROOT/'rtl/uart_reference.v').read_bytes()==(ROOT.parent/'fpga_audio_stage4/reference/top_uart.v').read_bytes(),
            parser_exact_original_copy=end_to_end['parser_identical_to_original'],
            e2e_passed=end_to_end['passed'],
            python_40_passed='Ran 40 tests' in (ROOT/'pc/reports/unittest.txt').read_text() and '\nOK\n' in (ROOT/'pc/reports/unittest.txt').read_text())
for hz in (440,1000):
    text=(RPT/f'vendor_xsim_{hz}.log').read_text()
    checks[f'vendor_simulation_{hz}_passed']='MIC_VENDOR_UART_PASS' in text and 'Fatal:' not in text
for gui in ('gui_smoke_result.json','gui_microphone_result.json','capture_gui_result.json'):
    checks[gui]=json.loads((ROOT/'pc/reports'/gui).read_text(encoding='utf-8'))['passed']
result=dict(passed=all(checks.values()),checks=checks,protected_files=len(before),changed_originals=changed,
            routed_WNS_ns=wns,routed_WHS_ns=whs,TNS_ns=tns,THS_ns=ths,
            drc_rules=drc_rules,validated_source_count=len(new_sources),
            bitstream_status='DEFERRED by explicit user instruction: Bank0 VCCO_0 and CFGBVS not confirmed',
            hardware_status='NOT TESTED: no microphone, front-end board, live COM6, JTAG or flash operations',
            scope='Digital implementation/model/PC tests passed; not approval for direct microphone connection or device programming')
(RPT/'final_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
if not result['passed']:raise SystemExit(1)
