set root [file dirname [file dirname [file normalize [info script]]]]
open_project [file join $root vivado microphone_audio microphone_audio.xpr]
add_files -fileset sim_1 -norecurse [list [file join $root tb tb_microphone.sv] [file join $root tb tb_faults.sv] [file join $root tb design.txt]]
foreach f {tb_microphone.sv tb_faults.sv} {
    set_property used_in_synthesis false [get_files -all *$f]
    set_property used_in_implementation false [get_files -all *$f]
}
set_property top tb_microphone [get_filesets sim_1]
set_property xsim.simulate.runtime {600ms} [get_filesets sim_1]
update_compile_order -fileset sim_1
# Recreate output products after the global-synthesis checkpoint property change.
generate_target all [get_ips xadc_wiz_mic]
puts "MIC_PROJECT_FINALIZED"
close_project
exit
