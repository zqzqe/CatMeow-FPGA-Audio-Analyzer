# MANUAL ONLY, AFTER board schematic verification. Never programs JTAG or flash.
# vivado -mode batch -source generate_bitstream.tcl -tclargs <CFGBVS> <CONFIG_VOLTAGE>
if {$argc != 2} {error "Supply board-confirmed CFGBVS and CONFIG_VOLTAGE; no defaults"}
set cfg [lindex $argv 0]
set volts [lindex $argv 1]
if {!(($cfg eq "VCCO" && $volts in {2.5 3.3}) || ($cfg eq "GND" && $volts in {1.5 1.8}))} {
    error "Unsupported configuration voltage pair. Consult actual board schematic."
}
set root [file dirname [file dirname [file normalize [info script]]]]
open_checkpoint [file join $root reports microphone_routed.dcp]
set_property CFGBVS $cfg [current_design]
set_property CONFIG_VOLTAGE $volts [current_design]
report_drc -file [file join $root reports drc_before_bitstream.rpt]
if {[llength [get_drc_violations -quiet -filter {SEVERITY == Error || SEVERITY == {Critical Warning}}]]} {
    error "Blocking DRC violations remain"
}
if {[get_property SLACK [get_timing_paths -delay_type max -max_paths 1]] < 0 ||
    [get_property SLACK [get_timing_paths -delay_type min -max_paths 1]] < 0} {error "Timing failure"}
file mkdir [file join $root bitstream]
write_bitstream [file join $root bitstream top_microphone_uart.bit]
puts "BITSTREAM_GENERATED_NO_DEVICE_PROGRAMMED"
exit
