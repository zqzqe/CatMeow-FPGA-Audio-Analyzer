"""AMD XADC analog file stimulus in ns; simulation only, never synthesized."""
import argparse
from pathlib import Path
import math

cli=argparse.ArgumentParser()
cli.add_argument('destination',type=Path)
cli.add_argument('--hz',type=int,default=440)
args=cli.parse_args()
with args.destination.open('w',encoding='ascii') as out:
    out.write('TIME TEMP VCCINT VCCBRAM VCCAUX VAUXP[15] VAUXN[15]\n')
    for ns in range(0,610000001,5000):
        voltage=.275+.2*math.sin(2*math.pi*args.hz*ns/1e9)
        out.write(f'{ns} 35 1.0 1.0 1.8 {voltage:.9f} 0.0\n')
