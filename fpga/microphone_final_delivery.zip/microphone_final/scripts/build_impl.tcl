set root [file dirname [file dirname [file normalize [info script]]]]
set rpt [file join $root reports]
open_project [file join $root vivado microphone_audio microphone_audio.xpr]
set_param general.maxThreads 2
foreach f {uart_reference.v caud_audio_tx.v xadc_audio_capture.v top_microphone_uart.v} {
    add_files -norecurse [file join $root rtl $f]
}
add_files -fileset constrs_1 -norecurse [file join $root pins_microphone.xdc]
set_property top top_microphone_uart [get_filesets sources_1]
set_property generate_synth_checkpoint false [get_files -all *xadc_wiz_mic.xci]
generate_target all [get_ips xadc_wiz_mic]
update_compile_order -fileset sources_1
# Direct commands retain all logs/checkpoints and avoid touching any old project.
synth_design -top top_microphone_uart -part xc7a75tfgg484-2
if {[llength [get_cells -quiet -hier -filter {IS_BLACKBOX == 1}]] != 0} {error "Unresolved cells"}
if {[llength [get_cells -quiet -hier -filter {REF_NAME == XADC}]] != 1} {error "Expected exactly one XADC"}
report_utilization -file [file join $rpt utilization_synth.rpt]
report_timing_summary -file [file join $rpt timing_synth.rpt]
write_checkpoint -force [file join $rpt microphone_synth.dcp]
puts "MIC_SYNTH_PASS"
opt_design
place_design
phys_opt_design
route_design
report_route_status -file [file join $rpt route_status.rpt]
report_timing_summary -delay_type min_max -report_unconstrained -file [file join $rpt timing_routed.rpt]
report_drc -file [file join $rpt drc_routed.rpt]
report_methodology -file [file join $rpt methodology.rpt]
report_utilization -file [file join $rpt utilization_routed.rpt]
report_io -file [file join $rpt io.rpt]
write_checkpoint -force [file join $rpt microphone_routed.dcp]
set setup [get_timing_paths -delay_type max -max_paths 1]
set hold [get_timing_paths -delay_type min -max_paths 1]
if {[get_property SLACK $setup] < 0 || [get_property SLACK $hold] < 0} {error "Routed timing failure"}
puts "MIC_IMPLEMENTATION_PASS"
puts "BITSTREAM_NOT_GENERATED: Bank0 CFGBVS/CONFIG_VOLTAGE and analog front-end bench verification remain unconfirmed."
close_project
exit
