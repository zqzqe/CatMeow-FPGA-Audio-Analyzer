"""AMD XADC analog simulation -> physical UART bits -> unchanged V0.3 parser."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'pc'))
from audio_protocol import FrameParser, SIMULATED
from features import extract_features
from session import AudioSession, save_session, save_features, save_samples_csv
from legacy.audio import spectrum

# Also verify with the preserved original PC parser, not just the new copy.
spec=importlib.util.spec_from_file_location('original_v03_protocol',ROOT.parent/'cat_analyzer_v03'/'audio_protocol.py')
original=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=original
spec.loader.exec_module(original)

results=[]
for hz in (440,1000):
    wire=bytes.fromhex((ROOT/'reports'/f'SIMULATION_uart_{hz}.hex').read_text())
    expected=bytes.fromhex((ROOT/'reports'/f'SIMULATION_adc_{hz}.hex').read_text())
    frames=[]; parser=FrameParser()
    rng=np.random.default_rng(732);offset=0
    while offset<len(wire):
        count=int(rng.integers(1,800));frames+=parser.feed(wire[offset:offset+count]);offset+=count
    old=original.FrameParser();old_frames=old.feed(wire)
    assert len(frames)==len(old_frames)==16
    assert b''.join(f.payload for f in frames)==expected
    assert all(f.rate==8000 and not f.flags & SIMULATED for f in frames)
    assert frames[0].flags==2 and all(f.flags==0 for f in frames[1:])
    for key in ('crc_errors','header_errors','lost_frames','lost_samples','duplicates','out_of_order'):
        assert parser.stats[key]==old.stats[key]==0,(key,parser.stats,old.stats)
    samples=np.concatenate([f.samples for f in frames])
    f,a=spectrum(samples,8000);peak=float(f[np.argmax(a)])
    assert abs(peak-hz)<=8000/len(samples)
    session=AudioSession()
    for frame in frames:session.ingest(frame,'仿真验证：AMD XADC 模型；非真实麦克风')
    # File output names and manifests preserve provenance even with wire flag=0.
    (ROOT/'reports'/f'SIMULATION_uart_{hz}.bin').write_bytes(wire)
    stem=ROOT/'reports'/f'SIMULATION_XADC_{hz}'
    manifest=stem.with_suffix('.session.json')
    if not manifest.exists():save_session(session,stem.with_suffix('.wav'),parser.stats)
    save_features(session.features,stem.with_suffix('.features.csv'))
    sample_csv=stem.with_suffix('.samples.csv')
    if not sample_csv.exists():assert save_samples_csv(session,sample_csv)==4096
    results.append(dict(test_hz=hz,frames=16,samples=len(samples),fft_peak_hz=peak,
                        features=extract_features(samples,8000),stats=parser.stats,
                        original_v03_parser_passed=True,payload_matches_drdy=True,
                        provenance='SIMULATION ONLY; wire SIMULATED=0 exercises production protocol'))
result=dict(passed=True,tests=results,
            parser_identical_to_original=hashlib.sha256((ROOT/'pc/audio_protocol.py').read_bytes()).hexdigest()==hashlib.sha256((ROOT.parent/'cat_analyzer_v03/audio_protocol.py').read_bytes()).hexdigest())
(ROOT/'reports/python_end_to_end.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
