$ErrorActionPreference = 'Stop'
$here = Split-Path $PSScriptRoot -Parent
$workspace = Split-Path (Split-Path $here -Parent) -Parent
$scratch = Join-Path $workspace 'work\microphone_final_sim'
New-Item -ItemType Directory -Force $scratch | Out-Null
$oldTemp = $env:TEMP
$oldTmp = $env:TMP
$env:TEMP = $scratch
$env:TMP = $scratch
Push-Location $scratch
try {
    $wrapper = Join-Path $here 'vivado\microphone_audio\microphone_audio.gen\sources_1\ip\xadc_wiz_mic\xadc_wiz_mic.v'
    & 'D:\2025.2\Vivado\bin\xvlog.bat' --sv 'D:\2025.2\Vivado\data\verilog\src\glbl.v' $wrapper (Join-Path $here 'rtl\uart_reference.v') (Join-Path $here 'rtl\caud_audio_tx.v') (Join-Path $here 'rtl\xadc_audio_capture.v') (Join-Path $here 'rtl\top_microphone_uart.v') (Join-Path $here 'tb\tb_microphone.sv') (Join-Path $here 'tb\tb_faults.sv')
    if ($LASTEXITCODE -ne 0) { throw 'xvlog failed' }
    foreach ($tb in @('tb_faults','tb_microphone')) {
        & 'D:\2025.2\Vivado\bin\xelab.bat' $tb glbl -L unisims_ver -mt 2 -s $tb
        if ($LASTEXITCODE -ne 0) { throw 'xelab failed' }
    }
    & 'D:\2025.2\Vivado\bin\xsim.bat' tb_faults -runall -log (Join-Path $here 'reports\faults_xsim.log')
    if ($LASTEXITCODE -ne 0) { throw 'Fault simulation failed' }
    if ((Get-Content -Raw (Join-Path $here 'reports\faults_xsim.log')) -notmatch 'MIC_FAULT_TESTS_PASS') { throw 'Fault checks failed' }
    foreach ($hz in @(440,1000)) {
        & (Join-Path $workspace '.venv\Scripts\python.exe') (Join-Path $PSScriptRoot 'make_analog_stimulus.py') design.txt --hz $hz
        & 'D:\2025.2\Vivado\bin\xsim.bat' tb_microphone -runall -log (Join-Path $here "reports\vendor_xsim_$hz.log")
        if ($LASTEXITCODE -ne 0) { throw 'XADC simulation failed' }
        $log = Get-Content -Raw (Join-Path $here "reports\vendor_xsim_$hz.log")
        if ($log -notmatch 'MIC_VENDOR_UART_PASS' -or $log -match 'Fatal:') { throw 'XADC/UART assertions failed' }
        Copy-Item -LiteralPath uart_microphone.hex -Destination (Join-Path $here "reports\SIMULATION_uart_$hz.hex")
        Copy-Item -LiteralPath adc_samples.hex -Destination (Join-Path $here "reports\SIMULATION_adc_$hz.hex")
    }
} finally {
    Pop-Location
    $env:TEMP = $oldTemp
    $env:TMP = $oldTmp
}
