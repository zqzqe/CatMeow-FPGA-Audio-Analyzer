@echo off
setlocal
call "%~dp0start.bat" --mode audio --port COM6 --baud 115200 %*
