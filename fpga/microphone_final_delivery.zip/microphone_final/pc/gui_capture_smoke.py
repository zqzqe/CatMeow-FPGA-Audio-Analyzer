"""Actual Tk serial-mode replay test. Reads the capture; never opens COM6."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import tkinter as tk
import traceback
import numpy as np
from main import App, MODES, APP_DIR


def run(capture):
    capture = Path(capture).resolve()
    wire = capture.read_bytes()
    before = hashlib.sha256(wire).hexdigest()
    root = tk.Tk()
    app = App(root)
    result = dict(passed=False, capture=str(capture), callback_errors=[],
                  scope='Actual Tk GUI with capture-backed serial test double; COM6 is not opened')
    root.report_callback_exception = lambda kind, value, tb: result['callback_errors'].append(str(value))
    receiver = None
    started = time.monotonic()

    class CaptureReceiver:
        def __init__(self): self.offset = 0; self.closed = False
        def open(self, *args): pass
        def read(self):
            # Leave the port silent first to check for fabricated samples.
            if time.monotonic()-started < .4:
                return b''
            part = wire[self.offset:self.offset+113]
            self.offset += len(part)
            return part
        def close(self): self.closed = True

    def guarded(callback):
        def invoke():
            try:
                callback()
            except Exception as exc:
                finish(exc)
        return invoke

    def empty_port():
        assert app.worker.snapshot()['valid'] == 0
        assert not app.session.segments
        assert 'FPGA实时音频数据' not in app.origin.get()
        result['silent_serial_no_fallback'] = True
        root.after(100, guarded(poll))

    def poll():
        if app.worker.snapshot()['valid'] == 425 and app.worker.events.empty():
            verify()
        elif time.monotonic()-started > 25:
            raise AssertionError(f'Replay timeout: {app.worker.snapshot()} / {app.status.get()}')
        else:
            root.after(100, guarded(poll))

    def verify():
        assert app.running, app.status.get()
        assert receiver.offset == len(wire)
        assert app.session.rate == 8000
        assert sum(s.count for s in app.session.segments) == 108800
        assert len(app.session.segments) == 1
        assert 'FPGA实时音频数据' in app.origin.get()
        assert '模拟数据' in app.origin.get()
        assert '8000 Hz' in app.rate_text.get()
        assert '有效帧 425' in app.protocol_text.get()
        assert 'CRC错误 0' in app.protocol_text.get()
        assert '丢帧 0' in app.protocol_text.get()
        assert app.worker.snapshot()['queue_drops'] == 0
        assert len(app.wave_line.get_ydata()) == 4096
        assert len(app.fft_line.get_ydata()) == 513
        expected = (np.frombuffer(wire[424*292+32:424*292+288], dtype='u1').astype(float)-128)/128
        np.testing.assert_array_equal(app.session.waveform[-256:], expected)
        assert abs(app.session.latest['dominant_hz']-440) < 8000/1024
        app.figure.savefig(APP_DIR/'reports'/'capture_gui_plot.png')
        result.update(valid_frames=425, valid_samples=108800, sample_rate=app.session.rate,
                      gui_fft_peak_bin_hz=app.session.latest['dominant_hz'],
                      waveform_samples=len(app.wave_line.get_ydata()),
                      fft_bins=len(app.fft_line.get_ydata()), source_label=app.origin.get(),
                      counter_label=app.protocol_text.get(), queue_drops=app.worker.snapshot()['queue_drops'],
                      draw_count=app.draw_count)
        app.stop()
        assert receiver.closed
        result['serial_closed_on_stop'] = True
        app.mode.set(MODES['raw'])
        app.switch_mode()
        class RawReceiver:
            def __init__(self): self.sent = False
            def open(self, *args): pass
            def close(self): pass
            def read(self):
                if self.sent: return b''
                self.sent = True
                return b'TEMP_RAW=9C32\r\nCAUD'
        app.start(serial_factory=RawReceiver)
        root.after(300, guarded(raw_check))

    def raw_check():
        assert app.raw_bytes == b'TEMP_RAW=9C32\r\nCAUD'
        assert app.worker.snapshot()['valid'] == 0
        assert not app.session.segments
        result['raw_mode_preserved'] = True
        finish()

    def finish(error=None):
        if error:
            result['error'] = repr(error)
            result['traceback'] = traceback.format_exc()
        result['capture_sha256_before'] = before
        result['capture_sha256_after'] = hashlib.sha256(capture.read_bytes()).hexdigest()
        result['passed'] = (error is None and not result['callback_errors'] and
                            result['capture_sha256_before'] == result['capture_sha256_after'])
        (APP_DIR/'reports'/'capture_gui_result.json').write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
        app.close()

    app.mode.set(MODES['audio'])
    app.switch_mode()
    app.port.set('CAPTURE_REPLAY_TEST')
    app.selected_rate.set('16000')  # Must not override the actual wire rate.
    receiver = CaptureReceiver()
    app.start(serial_factory=lambda: receiver)
    root.after(200, guarded(empty_port))
    root.mainloop()
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('capture', type=Path)
    raise SystemExit(run(cli.parse_args().capture))
