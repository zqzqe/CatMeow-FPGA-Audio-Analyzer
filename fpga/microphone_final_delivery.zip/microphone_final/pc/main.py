"""V0.3 desktop audio bench; stable V0.2 stays in its original directory."""
import os
from pathlib import Path
APP_DIR = Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR'] = str(APP_DIR / '.mplconfig')

import argparse
import csv
from datetime import datetime
import queue
import time
import tkinter as tk
from tkinter import ttk, filedialog
import numpy as np
from matplotlib import rcParams
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from legacy.audio import spectrum
from legacy.serial_receiver import SerialReceiver
from legacy.temperature import TemperatureParser, TemperatureHistory, temperature_celsius
from audio_protocol import U8, U12_LE, SIMULATED, wire_bytes_per_second
from features import FEATURE_NAMES
from signals import PROFILES
from transport import StreamWorker
from session import AudioSession, RecordingLimit, read_wav, save_session, save_features, save_samples_csv
from analysis_api import CLASSIFIER_STATUS

rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False
MODES = {'simulation': '模拟信号（模拟数据）', 'audio': '音频采集测试（串口）',
         'temperature': 'FPGA XADC 温度测试', 'raw': '串口原始字节', 'file': 'WAV 文件分析'}


class App:
    def __init__(self, root):
        self.root = root
        root.title('猫叫声智能分析系统 · V0.3 麦克风集成验证版')
        width = min(1140, root.winfo_screenwidth() - 100)
        height = min(850, root.winfo_screenheight() - 130)
        root.geometry(f'{max(640, width)}x{max(460, height)}')
        root.minsize(600, 420)
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('TButton', padding=(9, 5))
        self.mode = tk.StringVar(value=MODES['simulation'])
        self.port = tk.StringVar(value='COM6')
        self.baud = tk.StringVar(value='115200')
        self.profile = tk.StringVar(value=PROFILES[0])
        self.selected_rate = tk.StringVar(value='8000')
        self.sample_format = tk.StringVar(value='8 位 U8')
        self.origin = tk.StringVar()
        self.connection = tk.StringVar(value='串口：未连接')
        self.status = tk.StringVar(value='等待开始')
        self.rate_text = tk.StringVar(value='采样率：--')
        self.protocol_text = tk.StringVar(value='有效帧 0 | CRC错误 0 | 丢帧 0')
        self.metrics = tk.StringVar(value='主频 -- Hz    RMS --    能量 --')
        self.more_metrics = tk.StringVar(value='过零率 --    谱质心 -- Hz    谱带宽 -- Hz')
        self.temp_text = tk.StringVar(value='温度：-- °C  |  原始值：----  |  ADC Code：--')
        self.temp_time = tk.StringVar(value='最近有效更新：尚无数据')
        self.raw_text = tk.StringVar(value='HEX：尚无串口数据')
        self.worker = None
        self.test_transport = False
        self.running = False
        self.session = AudioSession()
        self.loaded_samples = None
        self.loaded_rate = None
        self.loaded_path = None
        self.last_audio = None
        self.last_temp = None
        self.temp_parser = TemperatureParser()
        self.temp_history = TemperatureHistory()
        self.temp_rows = []
        self.raw_bytes = bytearray()
        self.stats = {}
        self.draw_count = 0
        self.wrap_labels = []
        self._ui()
        self.switch_mode()
        self.job = root.after(80, self.tick)
        root.protocol('WM_DELETE_WINDOW', self.close)

    @property
    def mode_key(self):
        return next(key for key, label in MODES.items() if label == self.mode.get())

    def _ui(self):
        shell = ttk.Frame(self.root)
        shell.pack(fill='both', expand=True)
        self.scroll = tk.Canvas(shell, highlightthickness=0, background='#f6f8fa')
        scrollbar = ttk.Scrollbar(shell, orient='vertical', command=self.scroll.yview)
        scrollbar.pack(side='right', fill='y')
        self.scroll.pack(side='left', fill='both', expand=True)
        self.scroll.configure(yscrollcommand=scrollbar.set)
        self.content = ttk.Frame(self.scroll, padding=12)
        self.content_window = self.scroll.create_window(0, 0, window=self.content, anchor='nw')
        self.content.bind('<Configure>', lambda event: self.scroll.configure(scrollregion=self.scroll.bbox('all')))
        self.scroll.bind('<Configure>', self.resize_content)
        # Local to this toplevel, so other apps/windows keep their wheel behavior.
        self.root.bind('<MouseWheel>', lambda event: self.scroll.yview_scroll(-int(event.delta/120), 'units'))
        ttk.Label(self.content, text='猫叫声智能分析系统  V0.3', font=('Microsoft YaHei', 18, 'bold')).pack(anchor='w')
        self.origin_label = ttk.Label(self.content, textvariable=self.origin, foreground='#b45309', wraplength=900)
        self.origin_label.pack(anchor='w', pady=(5, 8), fill='x')
        settings = ttk.LabelFrame(self.content, text='采集与传输设置', padding=8)
        settings.pack(fill='x')
        settings.columnconfigure(1, weight=1)
        settings.columnconfigure(3, weight=1)
        ttk.Label(settings, text='模式').grid(row=0, column=0, sticky='w', padx=(0, 5))
        modebox = ttk.Combobox(settings, textvariable=self.mode, values=list(MODES.values()), state='readonly')
        modebox.grid(row=0, column=1, columnspan=4, sticky='ew', pady=3)
        modebox.bind('<<ComboboxSelected>>', lambda event: self.switch_mode())
        ttk.Label(settings, text='端口').grid(row=1, column=0, sticky='w')
        self.portbox = ttk.Combobox(settings, textvariable=self.port, width=10)
        self.portbox.grid(row=1, column=1, sticky='ew', padx=(0, 8), pady=3)
        ttk.Label(settings, text='波特率').grid(row=1, column=2, padx=5)
        self.baudbox = ttk.Combobox(settings, textvariable=self.baud, values=['115200', '230400', '460800', '921600'], width=12)
        self.baudbox.grid(row=1, column=3, sticky='ew')
        ttk.Button(settings, text='刷新', command=self.refresh_ports).grid(row=1, column=4, padx=(8, 0))
        ttk.Label(settings, text='模拟信号').grid(row=2, column=0, sticky='w')
        self.profilebox = ttk.Combobox(settings, textvariable=self.profile, values=PROFILES, state='readonly')
        self.profilebox.grid(row=2, column=1, columnspan=4, sticky='ew', pady=3)
        ttk.Label(settings, text='模拟采样率').grid(row=3, column=0, sticky='w')
        self.ratebox = ttk.Combobox(settings, textvariable=self.selected_rate, values=['8000', '16000'], width=10, state='readonly')
        self.ratebox.grid(row=3, column=1, sticky='ew', padx=(0, 8), pady=3)
        ttk.Label(settings, text='模拟编码').grid(row=3, column=2, padx=5)
        self.formatbox = ttk.Combobox(settings, textvariable=self.sample_format, values=['8 位 U8', '12 位 / 16 位容器'], width=16, state='readonly')
        self.formatbox.grid(row=3, column=3, columnspan=2, sticky='ew')
        actions = ttk.Frame(self.content)
        actions.pack(fill='x', pady=8)
        self.start_button = ttk.Button(actions, text='开始', command=self.start)
        self.start_button.pack(side='left', padx=(0, 5))
        ttk.Button(actions, text='停止', command=self.stop).pack(side='left', padx=3)
        ttk.Button(actions, text='保存数据', command=self.save_data).pack(side='left', padx=3)
        ttk.Button(actions, text='加载 WAV', command=self.load_wav_dialog).pack(side='left', padx=3)
        ttk.Button(actions, text='导出特征', command=self.export_features).pack(side='left', padx=3)
        sample_actions = ttk.Frame(self.content)
        sample_actions.pack(fill='x', pady=(0, 5))
        ttk.Button(sample_actions, text='导出采样 CSV', command=self.export_samples).pack(side='left')
        for variable in (self.connection, self.rate_text, self.protocol_text):
            label = ttk.Label(self.content, textvariable=variable, wraplength=900)
            label.pack(anchor='w', fill='x', pady=2)
            self.wrap_labels.append(label)
        self.audio_panel = ttk.Frame(self.content)
        self.audio_panel.pack(fill='x')
        for variable in (self.metrics, self.more_metrics):
            label = ttk.Label(self.audio_panel, textvariable=variable, wraplength=900)
            label.pack(anchor='w', fill='x', pady=3)
            self.wrap_labels.append(label)
        plot_host = ttk.Frame(self.audio_panel, height=380)
        plot_host.pack(fill='x')
        plot_host.pack_propagate(False)
        self.figure = Figure(figsize=(9, 3.8), dpi=100, layout='constrained')
        self.wave, self.fft = self.figure.subplots(2, 1)
        self.wave_line, = self.wave.plot([], [], linewidth=1, color='#0f766e')
        self.fft_line, = self.fft.plot([], [], linewidth=1, color='#2563eb')
        self.wave.set(title='音频波形（相对满量程）', xlabel='当前窗口时间 (s)', ylabel='幅度', ylim=(-1.05, 1.05))
        self.fft.set(title='FFT（去直流、Hann 窗）', xlabel='频率 (Hz)', ylabel='线性幅度', ylim=(0, 1))
        for ax in (self.wave, self.fft):
            ax.grid(alpha=0.2)
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_host)
        self.canvas.get_tk_widget().pack(fill='both', expand=True)
        self.canvas.mpl_connect('draw_event', lambda event: self._drawn())
        self.temp_panel = ttk.Frame(self.content)
        temp_label = ttk.Label(self.temp_panel, textvariable=self.temp_text, font=('Microsoft YaHei', 14, 'bold'), foreground='#0f766e', wraplength=900)
        temp_label.pack(anchor='w', fill='x', pady=8)
        self.wrap_labels.append(temp_label)
        ttk.Label(self.temp_panel, textvariable=self.temp_time).pack(anchor='w')
        temp_host = ttk.Frame(self.temp_panel, height=330)
        temp_host.pack(fill='x')
        temp_host.pack_propagate(False)
        self.temp_figure = Figure(figsize=(9, 3.3), dpi=100, layout='constrained')
        self.temp_axes = self.temp_figure.subplots()
        self.temp_axes.set(title='FPGA 内部温度 · 最近 60 秒', xlabel='相对当前时间 (s)', ylabel='温度 (°C)', xlim=(-60, 0), ylim=(0, 100))
        self.temp_axes.grid(alpha=0.2)
        self.temp_line, = self.temp_axes.plot([], [], color='#0f766e', marker='o', markersize=3)
        self.temp_canvas = FigureCanvasTkAgg(self.temp_figure, master=temp_host)
        self.temp_canvas.get_tk_widget().pack(fill='both', expand=True)
        self.footer = ttk.Frame(self.content)
        self.footer.pack(fill='x', pady=(8, 0))
        self.status_label = ttk.Label(self.footer, textvariable=self.status, wraplength=900)
        self.status_label.pack(anchor='w', fill='x')
        self.raw_label = ttk.Label(self.footer, textvariable=self.raw_text, wraplength=900, font=('Consolas', 9))
        self.raw_label.pack(anchor='w', fill='x', pady=4)
        self.model_label = ttk.Label(self.footer, text=CLASSIFIER_STATUS, foreground='#64748b', wraplength=900)
        self.model_label.pack(anchor='w', fill='x', pady=(3, 8))
        self.refresh_ports()

    def _drawn(self):
        self.draw_count += 1

    def resize_content(self, event):
        self.scroll.itemconfigure(self.content_window, width=event.width)
        for label in (self.origin_label, self.status_label, self.raw_label, self.model_label, *self.wrap_labels):
            label.configure(wraplength=max(300, event.width - 35))

    def refresh_ports(self):
        try:
            self.portbox['values'] = SerialReceiver.ports()
        except Exception as exc:
            self.status.set(f'端口枚举失败，可手动输入：{exc}')

    def _settings_state(self, active):
        for box in (self.portbox, self.baudbox):
            box.configure(state='disabled' if active else 'normal')
        for box in (self.profilebox, self.ratebox, self.formatbox):
            box.configure(state='disabled' if active else 'readonly')
        self.start_button.configure(state='disabled' if active else 'normal')

    def reset_data(self):
        self.session = AudioSession()
        self.temp_parser = TemperatureParser()
        self.temp_history = TemperatureHistory()
        self.temp_rows = []
        self.raw_bytes = bytearray()
        self.last_audio = self.last_temp = None
        self.stats = {}
        self.wave_line.set_data([], [])
        self.fft_line.set_data([], [])
        self.temp_line.set_data([], [])
        self.temp_text.set('温度：-- °C  |  原始值：----  |  ADC Code：--')
        self.temp_time.set('最近有效更新：尚无数据')
        self.metrics.set('主频 -- Hz    RMS --    峰值 --    能量 --')
        self.more_metrics.set('过零率 --    谱质心 -- Hz    谱带宽 -- Hz')
        self.raw_text.set('HEX：尚无串口数据')
        self.rate_text.set('采样率：等待完整有效帧')
        self.protocol_text.set('有效帧 0 | CRC错误 0 | 丢帧 0')
        self.canvas.draw_idle()
        self.temp_canvas.draw_idle()

    def switch_mode(self):
        self.stop()
        self.worker = None
        self.reset_data()
        self.test_transport = False
        mode = self.mode_key
        self.audio_panel.pack_forget()
        self.temp_panel.pack_forget()
        if mode == 'temperature':
            self.temp_panel.pack(fill='x', before=self.footer)
            self.origin.set('FPGA XADC 内部温度测试；不是音频，不用于情绪判断')
            self.rate_text.set('温度报告：预期每秒约 1 行；高 12 位换算')
        elif mode == 'raw':
            self.origin.set('原始串口字节；不解释为音频或温度')
        else:
            self.audio_panel.pack(fill='x', before=self.footer)
            self.origin.set({'simulation': '模拟数据 · 经过 CAUD 封包、UART 速率模拟、分段接收和 CRC 解包',
                             'audio': '串口音频测试 · 等待 CAUD/1；真实麦克风采集尚未验证',
                             'file': 'WAV 文件回放 · 文件来源未验证，不等同于 FPGA 采集'}[mode])
        self.connection.set('串口：未连接')
        self.status.set('等待开始；新会话会清空当前内存数据，请先保存')

    def start(self, serial_factory=None):
        if self.running:
            return
        if self.worker and self.worker.thread and self.worker.thread.is_alive():
            self.status.set('上一接收线程仍在退出，请稍后再开始')
            return
        try:
            baud = int(self.baud.get())
            rate = int(self.selected_rate.get())
            fmt = U8 if self.sample_format.get() == '8 位 U8' else U12_LE
            if baud <= 0:
                raise ValueError('波特率必须为正整数')
            if self.mode_key == 'file':
                if self.loaded_samples is None:
                    raise ValueError('请先加载 WAV')
                rate = self.loaded_rate
            if self.mode_key == 'simulation' and wire_bytes_per_second(rate, fmt) > baud / 10 * 0.85:
                raise ValueError('含协议开销后超出 85% 带宽预算；16 kHz 请用 460800 或以上')
        except ValueError as exc:
            self.status.set(str(exc))
            return
        self.reset_data()
        self.test_transport = serial_factory is not None
        self.worker = StreamWorker(self.mode_key, self.port.get().strip(), baud,
                                   self.profile.get(), rate, fmt, self.loaded_samples, serial_factory)
        self.worker.start()
        self.running = True
        self._settings_state(True)
        if self.mode_key == 'simulation':
            self.origin.set(f'模拟数据 · {self.profile.get()} · 完整 CAUD 协议链路 · 非 FPGA 实测')
        elif self.mode_key == 'audio':
            self.origin.set('串口音频测试 · 等待有效 CAUD 帧；不会自动生成模拟音频')
        elif self.mode_key == 'file':
            self.origin.set(f'WAV 文件回放 · {Path(self.loaded_path).name if self.loaded_path else "测试文件"} · 来源未验证')
        self.status.set('正在启动后台接收任务…')

    def stop(self):
        self.running = False
        if self.worker:
            closed = self.worker.stop()
            self.stats = self.worker.snapshot()
            self.connection.set('已停止 / 串口已释放' if closed else '接收线程退出中')
        self._settings_state(False)
        self.status.set('已停止；保留数据，可保存 WAV/CSV；开始新会话会清空')

    def _events(self, now):
        if not self.worker:
            return
        for _ in range(32):
            try:
                event = self.worker.events.get_nowait()
            except queue.Empty:
                break
            if event.kind == 'audio':
                frame = event.value
                if self.mode_key == 'file':
                    source = 'WAV文件（来源未验证）'
                elif frame.flags & SIMULATED:
                    source = '模拟数据' if self.mode_key == 'simulation' else '模拟数据（串口帧声明）'
                else:
                    source = '外部麦克风 / XADC通道15路径（SIMULATED=0帧声明；待硬件验证）'
                if self.mode_key == 'audio' and self.test_transport:
                    source = '仿真/回放测试数据（串口替身；非实板采集）' + (' · 模拟数据' if frame.flags & SIMULATED else '')
                self.session.ingest(frame, source)
                self.last_audio = now
                self.rate_text.set(f'采样率：{frame.rate} Hz  |  录入 {self.session.seconds:.2f} s  |  连续分段 {len(self.session.segments)}')
                if self.mode_key == 'audio':
                    detail = ('FPGA 内部数字测试音频 / 模拟数据（SIMULATED=1）'
                              if frame.flags & SIMULATED else source)
                    prefix = '仿真/回放验证 · FPGA实时音频数据解析链路' if self.test_transport else 'FPGA实时音频数据'
                    self.origin.set(f'{prefix} · 串口有效 CAUD 帧 · {detail}；未验证麦克风采集')
            else:
                data = event.value
                self.raw_text.set('HEX：' + data[-32:].hex(' ').upper())
                if self.mode_key == 'temperature':
                    for raw in self.temp_parser.feed(data):
                        celsius = temperature_celsius(raw)
                        self.last_temp = now
                        self.temp_history.add(now, celsius)
                        timestamp = datetime.now().isoformat(timespec='seconds')
                        self.temp_rows.append(dict(time=timestamp, raw=f'{raw:04X}', adc_code=raw >> 4, celsius=celsius))
                        self.temp_rows = self.temp_rows[-7200:]
                        self.temp_text.set(f'温度：{celsius:.2f} °C  |  原始值：{raw:04X}  |  ADC Code：{raw >> 4}')
                        self.temp_time.set(f'最近有效更新：{timestamp}')
                else:
                    self.raw_bytes.extend(data)
                    del self.raw_bytes[:-1048576]

    def redraw(self, now):
        if self.mode_key == 'temperature':
            x, y = self.temp_history.plot_data(now)
            self.temp_line.set_data(x, y)
            if y:
                self.temp_axes.set_ylim(min(y)-max(1, (max(y)-min(y))*.15), max(y)+max(1, (max(y)-min(y))*.15))
            self.temp_canvas.draw_idle()
        elif self.session.rate:
            rate = self.session.rate
            samples = self.session.waveform
            self.wave_line.set_data(np.arange(len(samples))/rate, samples)
            self.wave.set_xlim(0, max(len(samples)/rate, 0.01))
            if len(samples) >= 4:
                # Display the same 1024-sample window used for latest features.
                if self.session.latest:
                    segment = self.session.segments[-1]
                    start = self.session.latest['sample_index']
                    end = start + 1024
                    # waveform holds the newest 4096 samples, enough to retrieve
                    # the most recently completed analysis frame.
                    relative = end - segment.count
                    offset_end = len(samples) + relative
                    fft_samples = samples[max(0, offset_end-1024):offset_end]
                else:
                    fft_samples = samples
                if len(fft_samples) >= 4:
                    self.fft_line.set_data(*spectrum(fft_samples, rate))
            self.fft.set_xlim(0, rate/2)
            self.canvas.draw_idle()
            feature = self.session.latest
            if feature:
                self.metrics.set(f'主频 {feature["dominant_hz"]:.1f} Hz    RMS {feature["rms"]:.4f}    峰值 {feature["peak"]:.4f}    能量 {feature["energy"]:.5f}')
                self.more_metrics.set(f'过零率 {feature["zcr"]:.4f}    谱质心 {feature["centroid_hz"]:.1f} Hz    谱带宽 {feature["bandwidth_hz"]:.1f} Hz')

    def tick(self):
        try:
            now = time.monotonic()
            self._events(now)
            if self.worker:
                self.stats = self.worker.snapshot()
                crc_errors = self.stats['crc_errors'] + self.stats['header_crc_errors']
                self.protocol_text.set(
                    f'有效帧 {self.stats["valid"]} | CRC错误 {crc_errors} '
                    f'（头 {self.stats["header_crc_errors"]} / 帧 {self.stats["crc_errors"]}）'
                    f' | 丢帧 {self.stats["lost_frames"]} | 丢采样 {self.stats["lost_samples"]}'
                    f' | 接收 {self.stats["bytes"]} B | 待解析 {self.stats["pending_bytes"]} B')
                if self.running:
                    self.connection.set(self.stats['status'])
                    if self.stats['error']:
                        self.stop()
                        self.connection.set('串口/接收异常，未连接')
                        self.status.set('接收失败：' + self.stats['error'])
                    else:
                        if self.mode_key == 'temperature':
                            age = '等待有效温度' if self.last_temp is None else f'距有效更新 {now-self.last_temp:.1f}s' + ('（数据过期）' if now-self.last_temp > 3 else '')
                            self.status.set(f'{age} | 有效 {self.temp_parser.valid_lines} / 无效 {self.temp_parser.invalid_lines} 行')
                        elif self.mode_key == 'raw':
                            self.status.set(f'接收 {self.stats["bytes"]} 字节；可保存最近最多 1 MiB 原始数据')
                        else:
                            stale = '等待完整有效音频帧' if self.last_audio is None else ('数据超过 3 秒未更新' if now-self.last_audio > 3 else '分析中')
                            self.status.set(f'{stale} | 头字段/CRC错误 {self.stats["header_errors"]} | 确认截断 {self.stats["truncated_frames"]} | 重复 {self.stats["duplicates"]} / 倒序 {self.stats["out_of_order"]} | 队列丢弃 {self.stats["queue_drops"]}')
                        if not self.worker.thread.is_alive() and self.worker.events.empty():
                            self.running = False
                            self._settings_state(False)
                            self.status.set('WAV 回放结束，可保存分析结果' if self.mode_key == 'file' else '接收任务已结束')
                self.redraw(now)
        except RecordingLimit as exc:
            self.stop()
            self.status.set(str(exc))
        except Exception as exc:
            self.stop()
            self.status.set(f'处理异常，已停止：{exc}')
        finally:
            self.job = self.root.after(80, self.tick)

    def save_data(self):
        mode = self.mode_key
        extension = '.csv' if mode == 'temperature' else '.bin' if mode == 'raw' else '.wav'
        name = ('SIMULATED_' if mode == 'simulation' else 'capture_') + datetime.now().strftime('%Y%m%d_%H%M%S') + extension
        chosen = filedialog.asksaveasfilename(parent=self.root, initialdir=APP_DIR/'recordings', initialfile=name, defaultextension=extension)
        if not chosen:
            return
        self.stop()
        try:
            self._events(time.monotonic())
            if mode == 'temperature':
                if not self.temp_rows:
                    raise ValueError('尚无有效温度数据')
                with Path(chosen).open('w', newline='', encoding='utf-8-sig') as stream:
                    writer = csv.DictWriter(stream, fieldnames=list(self.temp_rows[0]))
                    writer.writeheader()
                    writer.writerows(self.temp_rows)
                outputs = [chosen]
            elif mode == 'raw':
                if not self.raw_bytes:
                    raise ValueError('尚无原始字节')
                Path(chosen).write_bytes(self.raw_bytes)
                outputs = [chosen]
            else:
                outputs = save_session(self.session, chosen, self.stats)
            self.status.set('已保存：' + '、'.join(Path(path).name for path in outputs))
        except Exception as exc:
            self.status.set(f'保存失败：{exc}')

    def load_wav_dialog(self):
        selected = filedialog.askopenfilename(parent=self.root, filetypes=[('PCM WAV', '*.wav')])
        if selected:
            self.load_wav(selected)

    def load_wav(self, path):
        try:
            samples, rate = read_wav(path)
            self.mode.set(MODES['file'])
            self.switch_mode()
            self.loaded_samples, self.loaded_rate, self.loaded_path = samples, rate, path
            self.start()
        except Exception as exc:
            self.status.set(f'WAV 加载失败：{exc}')

    def export_features(self):
        chosen = filedialog.asksaveasfilename(parent=self.root, initialdir=APP_DIR/'recordings', initialfile='features.csv', defaultextension='.csv')
        if chosen:
            try:
                save_features(self.session.features, chosen)
                self.status.set('已导出最近最多 2048 帧特征：' + Path(chosen).name)
            except Exception as exc:
                self.status.set(f'特征导出失败：{exc}')

    def export_samples(self):
        chosen = filedialog.asksaveasfilename(parent=self.root, initialdir=APP_DIR/'recordings',
                                              initialfile='samples.csv', defaultextension='.csv')
        if chosen:
            self.stop()
            try:
                self._events(time.monotonic())
                count = save_samples_csv(self.session, chosen)
                self.status.set(f'已导出 {count} 个有效采样点：{Path(chosen).name}')
            except Exception as exc:
                self.status.set(f'采样导出失败：{exc}')

    def close(self):
        self.stop()
        self.root.after_cancel(self.job)
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description='V0.3 音频协议与分析台；默认仅运行模拟数据')
    parser.add_argument('--mode', choices=list(MODES), default='simulation')
    parser.add_argument('--profile', choices=['sine', 'dual', 'sweep', 'noise', 'legacy'], default='sine')
    parser.add_argument('--port', default='COM6')
    parser.add_argument('--baud', default='115200')
    parser.add_argument('--rate', choices=['8000', '16000'], default='8000')
    parser.add_argument('--format', choices=['u8', 'u12'], default='u8')
    parser.add_argument('--wav')
    parser.add_argument('--smoke-test', action='store_true')
    args = parser.parse_args()
    root = tk.Tk()
    app = App(root)
    app.mode.set(MODES[args.mode])
    app.profile.set(PROFILES[['sine', 'dual', 'sweep', 'noise', 'legacy'].index(args.profile)])
    app.port.set(args.port)
    app.baud.set(args.baud)
    app.selected_rate.set(args.rate)
    app.sample_format.set('8 位 U8' if args.format == 'u8' else '12 位 / 16 位容器')
    app.switch_mode()
    if args.smoke_test:
        from gui_smoke import schedule_smoke
        result = schedule_smoke(app)
    elif args.wav:
        app.load_wav(args.wav)
    else:
        app.start()
    root.mainloop()
    if args.smoke_test and not result.get('passed'):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
