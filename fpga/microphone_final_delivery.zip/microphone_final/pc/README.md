# V0.3 麦克风集成验证版

这是原V0.3的独立副本，原版本没有修改。本版本尚未进行真实麦克风硬件验证。

启动：双击本目录 start_audio.bat；或在原项目根目录执行：

```powershell
.\.venv\Scripts\python.exe .\outputs\microphone_final\pc\main.py --mode audio --port COM6 --baud 115200
```

start.bat 仍默认明确标识的模拟模式。使用原项目已有环境，无新增第三方包。移至其他机器时按 requirements.txt 安装依赖并用当地Python启动 main.py；批处理中的相对.venv路径仅适用于当前项目位置。

保留模拟、串口音频、温度、原始字节、WAV模式及原布局，使用原版CAUD解析器。串口SIMULATED=0显示外部麦克风/XADC15路径（帧声明；待硬件验证）；该标志本身不能证明已接入麦克风。SIMULATED=1继续显示数字测试/模拟数据。串口替身测试另标记仿真/回放，保存来源也保留此标记。无数据或端口失败时不回退为软件模拟。

采样率读取协议头，波形按(U8-128)/128。FFT、RMS、峰值、能量、过零率、谱质心/带宽基于去均值数据。峰值为分析窗中去均值后的最大绝对值，不是声压。1024点Hann窗、hop256，8kHz下频点间距7.8125Hz，440Hz实时最大频点为437.5Hz。保留120秒录制上限与2048项特征缓存。

“保存数据”导出WAV和session JSON；“导出特征”输出特征CSV；“导出采样CSV”输出实际采样、分段、来源、采样率、样本编号和分段相对时间。断帧分段，不伪造连续声音；采样CSV拒绝覆盖同名文件。硬件新顶层只发音频，温度模式应配合原温度Bitstream使用。没有情绪分类器或识别准确率。

测试（原项目根目录）：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s .\outputs\microphone_final\pc\tests -v
.\.venv\Scripts\python.exe .\outputs\microphone_final\pc\main.py --smoke-test
.\.venv\Scripts\python.exe .\outputs\microphone_final\pc\gui_microphone_smoke.py
```

40项测试及三组GUI冒烟测试通过。桌面 fpga_uart_capture.bin 回归仍只读，不存在时明确跳过，可用CAUD_CAPTURE_PATH指定路径，本次无跳过。新模型回放仿真不打开COM6，文件名SIMULATION不能作为实物证据。

交付操作与验证范围见 ../README.md 和 ../TEST_REPORT.md，调理电路见 ../hardware/FRONTEND.md。复制保留的旧CAPTURE_FIX_REPORT.md和TEST_REPORT.md属于原版本历史，本交付以父目录最新报告为准。
