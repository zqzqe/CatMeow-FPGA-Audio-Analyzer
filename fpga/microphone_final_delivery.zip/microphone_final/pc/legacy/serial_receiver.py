"""Raw byte transport only. ADC framing/encoding must be specified separately."""
import serial
from serial.tools import list_ports


class SerialReceiver:
    def __init__(self):
        self.connection = None
        self.total_bytes = 0

    @staticmethod
    def ports():
        return [port.device for port in list_ports.comports()]

    def open(self, port, baud):
        self.close()
        self.total_bytes = 0
        # Explicit, editable host transport defaults, not an FPGA protocol claim.
        self.connection = serial.Serial(port=port, baudrate=baud, timeout=0,
                                        bytesize=8, parity='N', stopbits=1,
                                        xonxoff=False, rtscts=False, dsrdtr=False)

    def read(self):
        if self.connection is None:
            return b''
        data = self.connection.read(min(self.connection.in_waiting, 4096))
        self.total_bytes += len(data)
        return data

    def close(self):
        if self.connection is not None:
            try:
                self.connection.close()
            finally:
                self.connection = None
