"""Incremental TEMP_RAW line parser and internal die-temperature conversion."""
import re
from collections import deque


def temperature_celsius(raw):
    if not isinstance(raw, int) or not 0 <= raw <= 0xFFFF:
        raise ValueError('Raw value must be an unsigned 16-bit integer')
    return (raw >> 4) * 503.975 / 4096 - 273.15


class TemperatureParser:
    def __init__(self, max_line_bytes=128):
        self.max_line_bytes = max_line_bytes
        self.pending = bytearray()
        self.discarding = False
        self.valid_lines = 0
        self.invalid_lines = 0

    def feed(self, data):
        values = []
        for byte in data:
            if byte == 10:
                if not self.discarding:
                    line = bytes(self.pending)
                    if line.endswith(b'\r'):
                        line = line[:-1]
                    match = re.fullmatch(rb'TEMP_RAW=([0-9A-Fa-f]{4})', line)
                    if match:
                        values.append(int(match[1], 16))
                        self.valid_lines += 1
                    else:
                        self.invalid_lines += 1
                self.pending.clear()
                self.discarding = False
            elif not self.discarding:
                if len(self.pending) >= self.max_line_bytes:
                    self.pending.clear()
                    self.discarding = True
                    self.invalid_lines += 1
                else:
                    self.pending.append(byte)
        return values


class TemperatureHistory:
    def __init__(self):
        self.points = deque(maxlen=4096)

    def add(self, timestamp, temperature):
        self.points.append((timestamp, temperature))
        self.prune(timestamp)

    def prune(self, now):
        while self.points and self.points[0][0] < now - 60:
            self.points.popleft()

    def plot_data(self, now):
        self.prune(now)
        return ([timestamp - now for timestamp, _ in self.points],
                [value for _, value in self.points])
