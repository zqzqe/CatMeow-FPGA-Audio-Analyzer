"""Unmodified V0.2 numerical, serial and temperature module snapshots."""
