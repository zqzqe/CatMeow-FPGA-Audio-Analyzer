"""Synthetic signal and single-sided amplitude spectrum; no classifier."""
import numpy as np


class Simulator:
    def __init__(self, sample_rate=16000, seed=None):
        self.sample_rate = sample_rate
        self.position = 0
        self.rng = np.random.default_rng(seed)

    def read(self, count):
        t = (np.arange(count) + self.position) / self.sample_rate
        # Synthetic harmonic sweep, not a recording or validated cat model.
        phase = 2 * np.pi * (550 * t + 80 / (2 * np.pi * 0.7) * (1 - np.cos(2 * np.pi * 0.7 * t)))
        envelope = 0.3 + 0.7 * np.sin(np.pi * 0.55 * t) ** 2
        samples = envelope * (0.55 * np.sin(phase) + 0.2 * np.sin(2 * phase))
        samples += self.rng.normal(0, 0.015, count)
        self.position += count
        return samples


def spectrum(samples, sample_rate):
    x = np.asarray(samples, dtype=float)
    if x.ndim != 1 or x.size < 4 or sample_rate <= 0:
        raise ValueError('Need at least four samples and a positive sample rate')
    window = np.hanning(x.size)
    amplitude = np.abs(np.fft.rfft((x - x.mean()) * window)) / window.sum()
    amplitude[1:] *= 2
    if x.size % 2 == 0:
        amplitude[-1] /= 2
    return np.fft.rfftfreq(x.size, 1 / sample_rate), amplitude
