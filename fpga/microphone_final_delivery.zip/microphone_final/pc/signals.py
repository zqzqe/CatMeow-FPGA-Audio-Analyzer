"""Known artificial signals for the full packet/transport/parser pipeline."""
import numpy as np
from legacy.audio import Simulator

PROFILES = ('正弦 500 Hz', '双音 500 + 1200 Hz', '扫频 300–2800 Hz',
            '含噪声 1000 Hz', 'V0.2 合成谐波')


class TestSignal:
    def __init__(self, profile=PROFILES[0], rate=8000, seed=42):
        if profile not in PROFILES:
            raise ValueError('Unknown test profile')
        self.profile, self.rate, self.position = profile, rate, 0
        self.rng = np.random.default_rng(seed)
        self.original = Simulator(rate, seed)

    def read(self, count):
        t = (np.arange(count) + self.position) / self.rate
        if self.profile == PROFILES[0]:
            x = 0.7 * np.sin(2 * np.pi * 500 * t)
        elif self.profile == PROFILES[1]:
            x = 0.55 * np.sin(2 * np.pi * 500 * t) + 0.3 * np.sin(2 * np.pi * 1200 * t)
        elif self.profile == PROFILES[2]:
            local = t % 2
            phase = 300 * local + (2800 - 300) * local ** 2 / 4
            x = 0.7 * np.sin(2 * np.pi * phase)
        elif self.profile == PROFILES[3]:
            x = 0.6 * np.sin(2 * np.pi * 1000 * t) + self.rng.normal(0, 0.08, count)
        else:
            x = self.original.read(count)
        self.position += count
        return np.clip(x, -1, 1)
