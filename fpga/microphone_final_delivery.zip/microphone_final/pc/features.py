"""Framed audio features; all amplitudes are relative full scale, not SPL."""
from collections import deque
import numpy as np
from legacy.audio import spectrum

FEATURE_NAMES = ('dominant_hz', 'rms', 'peak', 'energy', 'zcr', 'centroid_hz', 'bandwidth_hz')


def extract_features(samples, rate):
    x = np.asarray(samples, dtype=float)
    if x.ndim != 1 or len(x) < 4 or rate <= 0 or not np.isfinite(x).all():
        raise ValueError('Invalid audio frame')
    centered = x - x.mean()
    if np.max(np.abs(centered)) < 1e-12:
        centered = np.zeros_like(centered)
    frequency, amplitude = spectrum(centered, rate)
    amplitude[0] = 0
    energy = float(np.mean(centered ** 2))
    mass = float(amplitude.sum())
    if mass < 1e-10:
        dominant = centroid = bandwidth = 0.0
    else:
        dominant = float(frequency[np.argmax(amplitude)])
        centroid = float(np.dot(frequency, amplitude) / mass)
        bandwidth = float(np.sqrt(np.dot((frequency-centroid) ** 2, amplitude) / mass))
    return dict(dominant_hz=dominant, rms=float(np.sqrt(energy)),
                peak=float(np.max(np.abs(centered))), energy=energy,
                zcr=float(np.count_nonzero(np.diff(centered >= 0)) / (len(x)-1)),
                centroid_hz=centroid, bandwidth_hz=bandwidth)


class FeatureStream:
    def __init__(self, rate, frame_size=1024, hop_size=256, cache_size=2048):
        self.rate, self.frame_size, self.hop_size = rate, frame_size, hop_size
        self.pending = np.empty(0)
        self.position = 0
        self.cache = deque(maxlen=cache_size)

    def feed(self, samples):
        self.pending = np.concatenate((self.pending, samples))
        produced = []
        while len(self.pending) >= self.frame_size:
            result = extract_features(self.pending[:self.frame_size], self.rate)
            result.update(sample_index=self.position, time_seconds=self.position/self.rate)
            self.cache.append(result)
            produced.append(result)
            self.pending = self.pending[self.hop_size:]
            self.position += self.hop_size
        return produced
