@echo off
setlocal
cd /d "%~dp0"
set "PROJECT_PYTHON=%~dp0..\..\..\.venv\Scripts\python.exe"
if not exist "%PROJECT_PYTHON%" (
  echo Project Python environment missing. See README.md.
  pause
  exit /b 1
)
"%PROJECT_PYTHON%" main.py %*
if errorlevel 1 pause
