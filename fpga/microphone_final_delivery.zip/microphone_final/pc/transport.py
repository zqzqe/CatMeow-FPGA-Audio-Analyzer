"""Background byte transport; never touches Tk widgets."""
from dataclasses import dataclass
import queue
import threading
import time
import numpy as np
from audio_protocol import (FrameParser, encode_frame, AudioFrame, SIMULATED,
                            RESET, U8, U12_LE, wire_bytes_per_second)
from legacy.serial_receiver import SerialReceiver
from signals import TestSignal


@dataclass
class Event:
    kind: str
    value: object


class StreamWorker:
    def __init__(self, mode, port='COM6', baud=115200, profile=None, rate=8000,
                 sample_format=U8, file_samples=None, serial_factory=None):
        self.mode, self.port, self.baud = mode, port, baud
        self.profile, self.rate, self.sample_format = profile, rate, sample_format
        self.file_samples, self.serial_factory = file_samples, serial_factory
        self.events = queue.Queue(maxsize=128)
        self.stop_event = threading.Event()
        self.thread = None
        self.parser = FrameParser()
        self.bytes_received = 0
        self.queue_drops = 0
        self.status = '准备中'
        self.error = None
        self.started_at = None
        self.last_received = None
        self.stats_lock = threading.Lock()

    def start(self):
        if self.thread and self.thread.is_alive():
            raise RuntimeError('Worker is already running')
        self.thread = threading.Thread(target=self._run, name='CAUD receiver', daemon=True)
        self.thread.start()

    def stop(self):
        # All real serial reads are non-blocking; this waits at most a short
        # poll interval in the normal path, not a UART read timeout.
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=0.5)
        return self.thread is None or not self.thread.is_alive()

    def snapshot(self):
        with self.stats_lock:
            return dict(self.parser.stats, bytes=self.bytes_received,
                        pending_bytes=len(self.parser.buffer),
                        queue_drops=self.queue_drops, status=self.status,
                        error=self.error, last_received=self.last_received)

    def _emit(self, kind, value):
        event = Event(kind, value)
        try:
            self.events.put_nowait(event)
        except queue.Full:
            try:
                self.events.get_nowait()
            except queue.Empty:
                pass
            self.queue_drops += 1
            self.events.put_nowait(event)

    def _consume(self, data):
        if not data:
            return
        with self.stats_lock:
            self.bytes_received += len(data)
            self.last_received = time.monotonic()
            frames = self.parser.feed(data) if self.mode in ('simulation', 'audio') else []
        if self.mode in ('temperature', 'raw'):
            self._emit('bytes', data)
        else:
            for frame in frames:
                self._emit('audio', frame)

    def _run(self):
        self.started_at = time.monotonic()
        try:
            if self.mode == 'simulation':
                if wire_bytes_per_second(self.rate, self.sample_format) > self.baud / 10 * 0.85:
                    raise ValueError('协议开销计入后超过 85% 串口预算；16 kHz 请选择 460800 或以上')
                self.status = '模拟链路运行中（未打开串口）'
                self._simulate()
            elif self.mode == 'file':
                self.status = 'WAV 文件回放（来源未验证）'
                self._file()
            else:
                receiver = self.serial_factory() if self.serial_factory else SerialReceiver()
                try:
                    receiver.open(self.port, self.baud)
                    self.status = f'已连接 {self.port} · {self.baud} · 8N1'
                    while not self.stop_event.is_set():
                        self._consume(receiver.read())
                        self.stop_event.wait(0.005)
                finally:
                    receiver.close()
        except Exception as exc:
            self.error = str(exc)
            self.status = '连接/接收失败，已断开'
        finally:
            if not self.error:
                self.status = '已停止 / 串口已释放' if self.stop_event.is_set() else '文件回放结束'

    def _simulate(self):
        signal = TestSignal(self.profile, self.rate)
        rng = np.random.default_rng(137)
        pending = bytearray()
        sequence = 0
        next_block = previous = time.monotonic()
        tokens = 0.0
        while not self.stop_event.is_set():
            now = time.monotonic()
            tokens = min(tokens + (now - previous) * self.baud / 10, self.baud / 10 * 0.1)
            previous = now
            while now >= next_block:
                first = signal.position
                pending.extend(encode_frame(signal.read(256), self.rate, sequence, first,
                                            self.sample_format, SIMULATED | (RESET if sequence == 0 else 0)))
                sequence = (sequence + 1) & 0xFFFFFFFF
                next_block += 256 / self.rate
                if len(pending) > 65536:
                    raise RuntimeError('模拟传输积压；数据未被伪造为连续采集')
            size = min(len(pending), int(tokens), int(rng.integers(1, 401)))
            if size:
                self._consume(bytes(pending[:size]))
                del pending[:size]
                tokens -= size
            self.stop_event.wait(0.002)

    def _file(self):
        samples = self.file_samples
        if samples is None:
            raise ValueError('请先加载 WAV 文件')
        deadline = time.monotonic()
        for first in range(0, len(samples), 256):
            if self.stop_event.is_set():
                return
            # File blocks are not wire packets; no fake serial/CRC statistics.
            frame = AudioFrame(self.rate, first//256, first, U8, 0, b'\x80')
            frame.samples = np.array(samples[first:first+256], copy=True)
            frame.sample_format = 0  # decoded WAV, not a UART wire format
            frame.gap = first == 0
            self._emit('audio', frame)
            deadline += len(frame.samples) / self.rate
            if self.stop_event.wait(max(0, deadline-time.monotonic())):
                return
