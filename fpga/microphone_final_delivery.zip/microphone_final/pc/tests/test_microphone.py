import csv
import json
from pathlib import Path
import sys
import unittest
import uuid
import numpy as np
APP=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(APP))
from audio_protocol import FrameParser,encode_frame,SIMULATED
from features import extract_features
from session import AudioSession,save_samples_csv,save_session,read_wav


class MicrophoneTests(unittest.TestCase):
    def test_peak_is_dc_removed(self):
        x=.25+.2*np.sin(2*np.pi*1000*np.arange(1024)/8000)
        feature=extract_features(x,8000)
        self.assertAlmostEqual(feature['peak'],.2,places=8)
        self.assertAlmostEqual(feature['rms'],.2/np.sqrt(2),places=8)

    def test_xadc_model_uart_compatible(self):
        for hz in (440,1000):
            raw=bytes.fromhex((APP.parent/'reports'/f'SIMULATION_uart_{hz}.hex').read_text())
            parser=FrameParser();frames=parser.feed(raw)
            self.assertEqual(len(frames),16)
            self.assertTrue(all(not f.flags & SIMULATED for f in frames))
            self.assertEqual(parser.stats['lost_frames'],0)

    def test_csv_wav_preserve_actual_samples_and_provenance(self):
        folder=APP.parent/'test_work'/uuid.uuid4().hex
        folder.mkdir(parents=True)
        parser=FrameParser();session=AudioSession()
        source='仿真验证；非实板'
        frame,=parser.feed(encode_frame(np.linspace(-.5,.5,256),flags=0))
        session.ingest(frame,source)
        path=folder/'samples.csv'
        self.assertEqual(save_samples_csv(session,path),256)
        with path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
        self.assertEqual(len(rows),256)
        self.assertTrue(all(row['source']==source for row in rows))
        np.testing.assert_array_equal([float(r['normalized_sample']) for r in rows],frame.samples)
        with self.assertRaises(FileExistsError):save_samples_csv(session,path)
        outputs=save_session(session,folder/'SIMULATION.wav')
        x,rate=read_wav(outputs[0]);self.assertEqual(rate,8000)
        np.testing.assert_allclose(x,frame.samples,atol=1/32768)
        self.assertEqual(json.loads(outputs[-1].read_text(encoding='utf-8'))['segments'][0]['source'],source)


if __name__=='__main__':unittest.main(verbosity=2)
