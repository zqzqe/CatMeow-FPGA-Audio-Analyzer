"""Fixed 292-byte UART regression; fixtures are built independently of encode_frame."""
import os
from pathlib import Path
import struct
import sys
import time
import unittest
import zlib
import numpy as np

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP))
from audio_protocol import FrameParser
from transport import StreamWorker
from validate_capture import analyze_capture


def wire_frame(sequence=0, first=None, flags=1):
    header = bytearray(32)
    header[:8] = b'CAUD\x01\x20\x01' + bytes([flags])
    struct.pack_into('<IIIHHI', header, 8, 8000, sequence,
                     sequence*256 if first is None else first, 256, 256, 0)
    struct.pack_into('<I', header, 28, zlib.crc32(header[:28]))
    pcm = bytes((i % 256 for i in range(256)))
    body = header + pcm
    return bytes(body) + struct.pack('<I', zlib.crc32(body))


def source_capture():
    return Path(os.environ.get('CAUD_CAPTURE_PATH', Path.home()/'Desktop'/'fpga_uart_capture.bin'))


class CaptureProtocolTests(unittest.TestCase):
    def test_independent_fixed_offsets_and_normalization(self):
        wire = wire_frame()
        self.assertEqual(len(wire), 292)
        parser = FrameParser()
        frame, = parser.feed(wire)
        self.assertEqual(frame.payload, wire[32:288])
        np.testing.assert_array_equal(frame.samples, (np.arange(256)-128)/128)
        self.assertEqual(parser.stats['valid_samples'], 256)

    def test_all_partial_tails_never_report_crc_error(self):
        wire = wire_frame()
        for length in range(1, 292):
            with self.subTest(length=length):
                parser = FrameParser()
                self.assertEqual(parser.feed(wire[:length]), [])
                self.assertEqual(parser.feed(b''), [])
                self.assertEqual(parser.stats['crc_errors'], 0)
                self.assertEqual(parser.stats['header_crc_errors'], 0)
                self.assertEqual(parser.stats['truncated_frames'], 0)
                self.assertEqual(len(parser.feed(wire[length:])), 1)
                self.assertEqual(parser.stats['header_crc_passed'], 1)
                self.assertEqual(parser.stats['frame_crc_passed'], 1)

    def test_complete_frames_with_123_byte_tail(self):
        parser = FrameParser()
        result = []
        data = wire_frame() + wire_frame(1) + wire_frame(2)[:123]
        for byte in data:
            result.extend(parser.feed(bytes([byte])))
        self.assertEqual([f.sequence for f in result], [0, 1])
        self.assertEqual(len(parser.buffer), 123)
        self.assertEqual(parser.stats['header_crc_passed'], 3)
        self.assertEqual(parser.stats['frame_crc_passed'], 2)
        self.assertEqual(parser.stats['crc_errors'], 0)
        self.assertEqual(len(parser.feed(wire_frame(2)[123:])), 1)
        self.assertEqual(parser.stats['header_crc_passed'], 3)

    def test_both_crc_errors_and_resync(self):
        bad_header, bad_body = bytearray(wire_frame(1)), bytearray(wire_frame(2))
        bad_header[28] ^= 1
        bad_body[80] ^= 1
        parser = FrameParser()
        data = b'junkC' + wire_frame(0) + bad_header + bad_body + wire_frame(3)
        frames = []
        for i in range(0, len(data), 17):
            frames.extend(parser.feed(data[i:i+17]))
        self.assertEqual([f.sequence for f in frames], [0, 3])
        self.assertEqual(parser.stats['header_crc_errors'], 1)
        self.assertEqual(parser.stats['crc_errors'], 1)
        self.assertEqual(parser.stats['lost_frames'], 2)
        self.assertEqual(parser.stats['lost_samples'], 512)

    def test_sample_discontinuity_without_sequence_loss(self):
        parser = FrameParser()
        frames = parser.feed(wire_frame() + wire_frame(1, first=512))
        self.assertEqual(parser.stats['lost_frames'], 0)
        self.assertEqual(parser.stats['lost_samples'], 256)
        self.assertTrue(frames[-1].gap)

    def test_serial_audio_uses_actual_bytes_only(self):
        wire = wire_frame()
        class Receiver:
            def __init__(self): self.at = 0; self.closed = False
            def open(self, *args): pass
            def read(self):
                part = wire[self.at:self.at+5]
                self.at += len(part)
                return part
            def close(self): self.closed = True
        receiver = Receiver()
        worker = StreamWorker('audio', rate=16000, serial_factory=lambda: receiver)
        worker.start()
        deadline = time.monotonic()+3
        while worker.snapshot()['valid'] < 1 and time.monotonic() < deadline:
            time.sleep(.005)
        worker.stop()
        event = worker.events.get_nowait()
        self.assertEqual(event.kind, 'audio')
        self.assertEqual(event.value.rate, 8000)  # header overrides GUI simulation setting
        self.assertEqual(event.value.payload, wire[32:288])
        self.assertTrue(receiver.closed)

    def test_raw_mode_does_not_parse_audio(self):
        worker = StreamWorker('raw')
        worker._consume(wire_frame())
        self.assertEqual(worker.events.get_nowait().value, wire_frame())
        self.assertEqual(worker.snapshot()['valid'], 0)

    def test_silent_port_has_no_simulation_fallback(self):
        class Silent:
            def open(self, *args): pass
            def read(self): return b''
            def close(self): pass
        worker = StreamWorker('audio', serial_factory=Silent)
        worker.start()
        time.sleep(.05)
        worker.stop()
        self.assertEqual(worker.snapshot()['valid'], 0)
        self.assertTrue(worker.events.empty())


class ActualCaptureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.path = source_capture()
        if not cls.path.is_file():
            raise unittest.SkipTest('Set CAUD_CAPTURE_PATH to the original fpga_uart_capture.bin')
        cls.result = analyze_capture(cls.path, expected_frames=425, expected_frequency=440)

    def test_actual_capture_all_acceptance_values(self):
        result = self.result
        self.assertTrue(result['passed'], result)
        self.assertEqual(result['complete_frames'], 425)
        self.assertEqual(result['header_crc_passed_complete'], 425)
        self.assertEqual(result['frame_crc_passed'], 425)
        self.assertEqual(result['valid_samples'], 108800)
        self.assertEqual(result['sample_rates'], [8000])
        self.assertAlmostEqual(result['fft_peak_hz'], 440, delta=.1)
        self.assertEqual(result['pending_tail_bytes'], 123)
        self.assertEqual(result['stats']['lost_frames'], 0)
        self.assertEqual(result['stats']['crc_errors'], 0)
        self.assertEqual(result['sha256_before'], result['sha256_after'])

    def test_actual_capture_all_chunk_patterns(self):
        wire = self.path.read_bytes()
        for size in (1, 31, 32, 113, 291, 292, 4096, len(wire)):
            with self.subTest(chunk_size=size):
                parser = FrameParser()
                frames = []
                for offset in range(0, len(wire), size):
                    frames.extend(parser.feed(wire[offset:offset+size]))
                self.assertEqual(len(frames), 425)
                self.assertEqual(sum(len(f.samples) for f in frames), 108800)
                self.assertEqual(parser.stats['frame_crc_passed'], 425)
                self.assertEqual(parser.stats['crc_errors'], 0)
                self.assertEqual(parser.stats['lost_frames'], 0)
                self.assertEqual(len(parser.buffer), 123)


if __name__ == '__main__':
    unittest.main(verbosity=2)
