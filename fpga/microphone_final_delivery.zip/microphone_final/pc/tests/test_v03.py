import json
from pathlib import Path
import struct
import sys
import time
import unittest
import uuid
import wave
import numpy as np

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP))
from audio_protocol import *
from features import extract_features, FeatureStream
from signals import TestSignal, PROFILES
from session import AudioSession, save_session, read_wav, write_wav
from transport import StreamWorker
from legacy.temperature import TemperatureParser, temperature_celsius


def packet(seq=0, first=None, rate=8000, fmt=U8, flags=SIMULATED):
    x = TestSignal(PROFILES[0], rate).read(256)
    return encode_frame(x, rate, seq, seq*256 if first is None else first, fmt, flags)


class ProtocolTests(unittest.TestCase):
    def test_crc_standard(self):
        self.assertEqual(crc32(b'123456789'), 0xCBF43926)

    def test_full_frame(self):
        wire = packet()
        self.assertEqual(len(wire), 292)
        self.assertEqual(wire[:8], b'CAUD\x01\x20\x01\x01')
        frames = FrameParser().feed(wire)
        self.assertEqual(len(frames), 1)
        self.assertEqual((frames[0].rate, len(frames[0].samples)), (8000, 256))

    def test_every_split(self):
        wire = packet()
        for split in range(len(wire)+1):
            parser = FrameParser()
            self.assertEqual(len(parser.feed(wire[:split])+parser.feed(wire[split:])), 1)

    def test_bytewise_and_concatenation(self):
        parser = FrameParser()
        frames = []
        for byte in packet():
            frames.extend(parser.feed(bytes([byte])))
        frames += parser.feed(packet(1) + packet(2))
        self.assertEqual([x.sequence for x in frames], [0, 1, 2])

    def test_payload_crc_and_resync(self):
        broken = bytearray(packet(1))
        broken[40] ^= 1
        parser = FrameParser()
        frames = parser.feed(packet(0) + broken + packet(2))
        self.assertEqual([x.sequence for x in frames], [0, 2])
        self.assertEqual(parser.stats['crc_errors'], 1)
        self.assertEqual(parser.stats['lost_frames'], 1)
        self.assertTrue(frames[-1].gap)

    def test_header_crc(self):
        broken = bytearray(packet())
        broken[8] ^= 1
        parser = FrameParser()
        self.assertEqual(len(parser.feed(broken + packet(1))), 1)
        self.assertGreater(parser.stats['header_errors'], 0)

    def test_bad_length_with_valid_header_crc(self):
        broken = bytearray(packet())
        struct.pack_into('<H', broken, 22, 2048)
        struct.pack_into('<I', broken, 28, crc32(broken[:28]))
        parser = FrameParser()
        self.assertEqual(len(parser.feed(broken + packet(1))), 1)
        self.assertGreater(parser.stats['header_errors'], 0)

    def test_truncation_recovers_complete_successor(self):
        long_frame = encode_frame(np.zeros(1024), flags=SIMULATED)
        parser = FrameParser()
        frames = parser.feed(long_frame[:60] + packet(1))
        self.assertEqual([x.sequence for x in frames], [1])
        self.assertEqual(parser.stats['truncated_frames'], 1)
        self.assertEqual(parser.stats['crc_errors'], 0)

    def test_noise_bounded(self):
        parser = FrameParser()
        self.assertEqual(parser.feed(b'x'*100000), [])
        self.assertLessEqual(len(parser.buffer), 3)
        self.assertEqual(len(parser.feed(packet())), 1)

    def test_magic_in_payload(self):
        codes = np.full(256, 128, dtype='u1')
        codes[20:24] = list(b'CAUD')
        wire = encode_frame((codes.astype(float)-128)/128)
        self.assertEqual(len(FrameParser().feed(wire)), 1)

    def test_loss_duplicate_order_and_wrap(self):
        parser = FrameParser()
        frames = parser.feed(packet(0) + packet(2) + packet(2) + packet(1))
        self.assertEqual(len(frames), 2)
        self.assertEqual(parser.stats['lost_frames'], 1)
        self.assertEqual(parser.stats['lost_samples'], 256)
        self.assertEqual(parser.stats['duplicates'], 1)
        self.assertEqual(parser.stats['out_of_order'], 1)
        parser = FrameParser()
        result = parser.feed(packet(0xFFFFFFFF, first=0xFFFFFF00) + packet(0, first=0))
        self.assertFalse(result[-1].gap)

    def test_reset_and_config_change(self):
        parser = FrameParser()
        result = parser.feed(packet(7) + packet(0, flags=SIMULATED|RESET) + packet(1, rate=16000, fmt=U12_LE))
        self.assertEqual(len(result), 3)
        self.assertTrue(result[1].gap and result[2].gap)
        self.assertEqual(parser.stats['lost_frames'], 0)

    def test_u12_and_reserved_bits(self):
        wire = encode_frame([-1, 0, 1], rate=16000, sample_format=U12_LE)
        np.testing.assert_allclose(FrameParser().feed(wire)[0].samples, [-1, 0, 2047/2048])
        broken = bytearray(wire)
        struct.pack_into('<H', broken, 32, 0xFFFF)
        struct.pack_into('<I', broken, len(broken)-4, crc32(broken[:-4]))
        parser = FrameParser()
        self.assertEqual(parser.feed(broken), [])
        self.assertEqual(parser.stats['invalid_payloads'], 1)

    def test_bandwidth(self):
        self.assertEqual(wire_bytes_per_second(8000, U8), 9125)
        self.assertLess(wire_bytes_per_second(8000, U8), 115200/10*.85)
        self.assertEqual(wire_bytes_per_second(16000, U12_LE), 34250)
        self.assertLess(wire_bytes_per_second(16000, U12_LE), 460800/10*.85)


class AnalysisTests(unittest.TestCase):
    def pipeline(self, profile, rate=8000, fmt=U8, samples=8192):
        generator, parser, session = TestSignal(profile, rate), FrameParser(), AudioSession()
        wire = b''.join(encode_frame(generator.read(256), rate, i, i*256, fmt, SIMULATED)
                        for i in range(samples//256))
        rng = np.random.default_rng(90)
        offset = 0
        while offset < len(wire):
            size = int(rng.integers(1, 1000))
            for frame in parser.feed(wire[offset:offset+size]):
                session.ingest(frame, '模拟数据')
            offset += size
        return session

    def test_sine_peaks_two_rates(self):
        for rate, fmt in [(8000, U8), (16000, U12_LE)]:
            session = self.pipeline(PROFILES[0], rate, fmt)
            self.assertAlmostEqual(session.latest['dominant_hz'], 500, delta=rate/1024)
            self.assertAlmostEqual(session.latest['rms'], .7/np.sqrt(2), delta=.01)
            self.assertAlmostEqual(session.latest['energy'], .7**2/2, delta=.01)

    def test_dual_tone(self):
        session = self.pipeline(PROFILES[1])
        self.assertAlmostEqual(session.latest['dominant_hz'], 500, delta=8)
        f, a = __import__('legacy.audio', fromlist=['spectrum']).spectrum(session.waveform[-1024:], 8000)
        near = (f > 1180) & (f < 1220)
        self.assertGreater(a[near].max(), .2)

    def test_sweep_known_instantaneous_frequency(self):
        session = self.pipeline(PROFILES[2])
        feature = session.latest
        center = feature['time_seconds'] + 512/8000
        expected = 300 + 1250 * (center % 2)
        self.assertAlmostEqual(feature['dominant_hz'], expected, delta=30)

    def test_noisy_signal_peak(self):
        self.assertAlmostEqual(self.pipeline(PROFILES[3]).latest['dominant_hz'], 1000, delta=8)

    def test_zero_dc_zcr(self):
        self.assertTrue(all(value == 0 for value in extract_features(np.ones(1024)*.3, 8000).values()))
        x = np.sin(2*np.pi*500*np.arange(8000)/8000)
        self.assertAlmostEqual(extract_features(x, 8000)['zcr'], .125, delta=.002)

    def test_centroid_bandwidth_definition(self):
        x = .6*np.sin(2*np.pi*500*np.arange(1024)/8000)
        features = extract_features(x, 8000)
        self.assertAlmostEqual(features['centroid_hz'], 500, delta=2)
        self.assertLess(features['bandwidth_hz'], 15)

    def test_framing_cache_and_gap(self):
        stream = FeatureStream(8000, cache_size=2)
        self.assertEqual(stream.feed(np.zeros(1023)), [])
        self.assertEqual(len(stream.feed(np.zeros(1))), 1)
        stream.feed(np.zeros(1024))
        self.assertEqual(len(stream.cache), 2)
        session = AudioSession()
        parser = FrameParser()
        for frame in parser.feed(packet(0) + packet(2)):
            session.ingest(frame, '模拟数据')
        self.assertEqual(len(session.segments), 2)
        self.assertIsNone(session.latest)

    def test_wav_round_trip_and_gap_parts(self):
        folder = APP.parent/'test_work'/('wav_'+uuid.uuid4().hex)
        folder.mkdir(parents=True)
        session = self.pipeline(PROFILES[0])
        outputs = save_session(session, folder/'SIMULATED.wav')
        samples, rate = read_wav(outputs[0])
        self.assertEqual(rate, 8000)
        np.testing.assert_allclose(samples, np.concatenate(session.segments[0].chunks), atol=1/32768)
        self.assertAlmostEqual(extract_features(samples[-1024:], rate)['dominant_hz'], 500, delta=8)
        self.assertIn('模拟数据', Path(outputs[-1]).read_text(encoding='utf-8'))
        gap = AudioSession()
        for frame in FrameParser().feed(packet(0) + packet(2)):
            gap.ingest(frame, '模拟数据')
        outputs = save_session(gap, folder/'gap.wav')
        self.assertEqual(len(outputs), 3)
        self.assertIn('_part001', outputs[0].name)

    def test_wav_stereo_pcm8(self):
        folder = APP.parent/'test_work'/('pcm_'+uuid.uuid4().hex)
        folder.mkdir(parents=True)
        path = folder/'stereo.wav'
        with wave.open(str(path), 'wb') as out:
            out.setnchannels(2); out.setsampwidth(1); out.setframerate(8000)
            out.writeframes(bytes([0, 255, 128, 128]))
        x, rate = read_wav(path)
        np.testing.assert_allclose(x, [-1/256, 0])

    def test_temperature_preserved(self):
        parser = TemperatureParser()
        self.assertEqual(parser.feed(b'TEMP_RAW=9C'), [])
        self.assertEqual(parser.feed(b'32\r\n'), [0x9C32])
        self.assertAlmostEqual(temperature_celsius(0x9C32), 34.328887939453125)


class WorkerTests(unittest.TestCase):
    def test_background_full_pipeline(self):
        worker = StreamWorker('simulation', profile=PROFILES[0])
        worker.start()
        deadline = time.monotonic()+3
        frames = []
        while len(frames)<5 and time.monotonic()<deadline:
            try:
                frames.append(worker.events.get(timeout=.1).value)
            except __import__('queue').Empty:
                pass
        self.assertTrue(worker.stop())
        self.assertGreaterEqual(len(frames), 5)
        self.assertTrue(all(frame.flags & SIMULATED for frame in frames))
        self.assertGreater(worker.snapshot()['bytes'], 0)

    def test_invalid_bandwidth_fails(self):
        worker = StreamWorker('simulation', profile=PROFILES[0], rate=16000, sample_format=U12_LE)
        worker.start(); worker.thread.join(timeout=1)
        self.assertIsNotNone(worker.error)

    def test_serial_open_error_closes_receiver(self):
        class BadPort:
            closed = False
            def open(self, *args): raise OSError('port busy')
            def close(self): self.closed = True
        receiver = BadPort()
        worker = StreamWorker('audio', serial_factory=lambda: receiver)
        worker.start(); worker.thread.join(timeout=1)
        self.assertTrue(receiver.closed)
        self.assertIn('port busy', worker.error)


if __name__ == '__main__':
    unittest.main(verbosity=2)
