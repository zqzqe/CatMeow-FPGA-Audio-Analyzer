"""Read-only CAUD capture regression using the same parser as live serial."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zlib
import numpy as np
from audio_protocol import FrameParser, U8
from legacy.audio import spectrum


def analyze_capture(path, expected_frames=None, expected_frequency=None):
    path = Path(path).resolve()
    wire = path.read_bytes()
    before = hashlib.sha256(wire).hexdigest()
    parser = FrameParser()
    frames = []
    offset = 0
    sizes = (1, 2, 29, 3, 256, 11, 4096, 113)
    iteration = 0
    while offset < len(wire):
        count = sizes[iteration % len(sizes)]
        frames.extend(parser.feed(wire[offset:offset+count]))
        offset += count
        iteration += 1

    # Independent fixed-292-byte CRC inspection, without using the encoder.
    complete = header_ok = frame_ok = 0
    position = 0
    raw_metadata = []
    while True:
        at = wire.find(b'CAUD', position)
        if at < 0:
            break
        position = at + 1
        if len(wire) - at < 292:
            continue
        header = wire[at:at+32]
        if header[4:6] != b'\x01\x20':
            continue
        complete += 1
        h_ok = zlib.crc32(header[:28]) == struct.unpack_from('<I', header, 28)[0]
        f_ok = zlib.crc32(wire[at:at+288]) == struct.unpack_from('<I', wire, at+288)[0]
        header_ok += int(h_ok)
        frame_ok += int(f_ok)
        if h_ok and f_ok:
            raw_metadata.append(struct.unpack_from('<III', header, 8))
            position = at + 292  # PCM may itself contain the magic bytes.

    samples = np.concatenate([frame.samples for frame in frames]) if frames else np.empty(0)
    rates = sorted({frame.rate for frame in frames})
    frequency = amplitude = np.empty(0)
    peak = None
    if len(samples) >= 4 and len(rates) == 1:
        frequency, amplitude = spectrum(samples, rates[0])
        amplitude[0] = 0
        peak = float(frequency[np.argmax(amplitude)])
    continuous = all(
        (current.sequence-previous.sequence) & 0xFFFFFFFF == 1 and
        (current.first_sample-previous.first_sample) & 0xFFFFFFFF == len(previous.samples)
        for previous, current in zip(frames, frames[1:]))
    independent_continuous = all(
        (b[1]-a[1]) & 0xFFFFFFFF == 1 and (b[2]-a[2]) & 0xFFFFFFFF == 256
        for a, b in zip(raw_metadata, raw_metadata[1:]))
    after = hashlib.sha256(path.read_bytes()).hexdigest()
    checks = dict(
        has_frames=bool(frames),
        complete_crcs_match=complete == header_ok == frame_ok == len(frames),
        fixed_u8_256=all(f.sample_format == U8 and len(f.samples) == 256 for f in frames),
        sample_rate_8000=rates == [8000],
        continuous=continuous and independent_continuous,
        no_crc_errors=parser.stats['crc_errors'] == parser.stats['header_crc_errors'] == 0,
        no_losses=parser.stats['lost_frames'] == parser.stats['lost_samples'] == 0,
        no_repeated_frames=parser.stats['duplicates'] == parser.stats['out_of_order'] == 0,
        original_unchanged=before == after)
    if expected_frames is not None:
        checks['expected_frame_count'] = len(frames) == expected_frames
    if expected_frequency is not None:
        checks['expected_peak'] = peak is not None and abs(peak-expected_frequency) <= rates[0]/len(samples)
    return dict(passed=all(checks.values()), checks=checks, capture=str(path),
                byte_count=len(wire), sha256_before=before, sha256_after=after,
                complete_frames=complete, header_crc_passed_complete=header_ok,
                frame_crc_passed=frame_ok, valid_frames=len(frames),
                valid_samples=len(samples), sample_rates=rates, fft_peak_hz=peak,
                fft_resolution_hz=rates[0]/len(samples) if len(rates) == 1 and len(samples) else None,
                sequence_first=frames[0].sequence if frames else None,
                sequence_last=frames[-1].sequence if frames else None,
                first_sample=frames[0].first_sample if frames else None,
                pending_tail_bytes=len(parser.buffer), stats=dict(parser.stats),
                simulated_flag_frames=sum(bool(f.flags & 1) for f in frames),
                scope='Read-only replay of supplied UART bytes; no live COM6 or microphone test')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('capture', type=Path)
    cli.add_argument('--expect-frames', type=int)
    cli.add_argument('--expect-hz', type=float)
    cli.add_argument('--report', type=Path,
                     default=Path(__file__).resolve().parent/'reports'/'capture_validation.json')
    args = cli.parse_args()
    if args.report.resolve() == args.capture.resolve():
        cli.error('Report must not overwrite the capture file')
    result = analyze_capture(args.capture, args.expect_frames, args.expect_hz)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
