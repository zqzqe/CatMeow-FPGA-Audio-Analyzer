"""Real Tk smoke tests. All input is simulated or loopback; no COM6 is opened."""
import json
from pathlib import Path
import time
import traceback
import numpy as np
from legacy.serial_receiver import SerialReceiver
import serial
from session import save_session


def schedule_smoke(app):
    root = app.root
    from main import MODES, APP_DIR
    result = {'passed': False, 'callback_errors': [], 'source': 'simulation and loopback; no real FPGA audio'}
    root.report_callback_exception = lambda kind, value, tb: result['callback_errors'].append(str(value))
    app.mode.set(MODES['simulation'])
    app.switch_mode()
    app.start()

    def guarded(callback):
        def run():
            try:
                callback()
            except Exception as exc:
                finish(exc)
        return run

    def simulation():
        assert root.winfo_viewable()
        assert app.session.latest is not None, app.status.get()
        assert abs(app.session.latest['dominant_hz']-500)<8
        assert '模拟数据' in app.origin.get()
        assert app.draw_count > 2
        assert app.worker.snapshot()['valid'] >= 8
        first = app.session.waveform.copy()
        result.update(simulation_frames=app.worker.snapshot()['valid'], dominant_hz=app.session.latest['dominant_hz'])
        app.figure.savefig(APP_DIR/'reports'/'gui_simulation_plot.png')
        app.stop()
        fixture = APP_DIR/'reports'/'gui_saved_SIMULATED.wav'
        # Repeated smoke runs use a fresh output basename.
        if fixture.exists():
            fixture = fixture.with_name('gui_saved_SIMULATED_'+str(time.time_ns())+'.wav')
        result['saved_files'] = [str(path.name) for path in save_session(app.session, fixture, app.stats)]
        app.load_wav(fixture)
        root.after(1200, guarded(wav))

    def wav():
        assert app.session.latest and abs(app.session.latest['dominant_hz']-500)<8
        assert '来源未验证' in app.origin.get()
        result['wav_reload'] = True
        app.mode.set(MODES['temperature'])
        app.switch_mode()
        class LoopReceiver(SerialReceiver):
            def open(self, port, baud):
                self.connection = serial.serial_for_url('loop://', timeout=0)
                self.connection.write(b'TEMP_RAW=9C')
        app.start(serial_factory=LoopReceiver)
        root.after(250, guarded(temperature_partial))

    def temperature_partial():
        assert app.temp_parser.valid_lines == 0
        # Background loop has exclusive transport ownership; inject from an
        # independent fixture by using a fresh scripted receiver for the rest.
        app.stop()
        class ScriptedReceiver:
            def __init__(self): self.fragments=iter([b'TEMP_', b'RAW=9C32\r', b'\n'])
            def open(self, *args): pass
            def read(self): return next(self.fragments, b'')
            def close(self): pass
        app.start(serial_factory=ScriptedReceiver)
        root.after(500, guarded(temperature))

    def temperature():
        assert app.temp_parser.valid_lines == 1
        assert '34.33' in app.temp_text.get()
        assert app.temp_panel.winfo_viewable() and not app.audio_panel.winfo_viewable()
        result['temperature_regression'] = True
        app.stop()
        app.mode.set(MODES['audio']); app.switch_mode()
        class BusyReceiver:
            def open(self, *args): raise OSError('TEST busy port')
            def read(self): return b''
            def close(self): pass
        app.start(serial_factory=BusyReceiver)
        root.after(250, guarded(failed_port))

    def failed_port():
        assert not app.running and '失败' in app.status.get()
        assert not app.session.segments
        result['connection_error_no_fallback'] = True
        app.mode.set(MODES['simulation']); app.switch_mode(); app.start()
        root.geometry('640x480')
        root.after(500, guarded(layout))

    def layout():
        root.update_idletasks()
        # Full content is reachable by scrolling; no forced minimum wider than
        # the viewport or single-line toolbar hidden off the right edge.
        assert app.content.winfo_width() <= app.scroll.winfo_width()+1
        for button in app.content.winfo_children():
            if button.winfo_viewable():
                assert button.winfo_rootx()+button.winfo_width() <= root.winfo_rootx()+root.winfo_width(), str(button)
        app.scroll.yview_moveto(1)
        root.after(200, guarded(bottom))

    def bottom():
        assert app.model_label.winfo_rooty()+app.model_label.winfo_height() <= root.winfo_rooty()+root.winfo_height()+2
        result['small_window_scroll'] = True
        root.geometry('1100x800'); app.scroll.yview_moveto(0)
        root.after(200, guarded(lambda: finish()))

    def finish(error=None):
        result['callback_errors'] = list(result['callback_errors'])
        result['passed'] = error is None and not result['callback_errors']
        if error:
            result['error'] = repr(error)
            result['traceback'] = traceback.format_exc()
        (APP_DIR/'reports'/'gui_smoke_result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
        app.close()

    root.after(1800, guarded(simulation))
    return result
