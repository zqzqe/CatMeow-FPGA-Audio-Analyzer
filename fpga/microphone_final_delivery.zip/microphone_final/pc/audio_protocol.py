"""CAUD/1 binary protocol. See PROTOCOL.md for the exact wire contract."""
from dataclasses import dataclass, field
import struct
import zlib
import numpy as np

MAGIC = b'CAUD'
VERSION = 1
HEADER_SIZE = 32
PREFIX = struct.Struct('<4sBBBBIIIHHI')  # 28 bytes, followed by header CRC32
U8, U12_LE = 1, 2
SIMULATED, RESET, DISCONTINUITY = 1, 2, 4
MAX_SAMPLES = 1024
RATES = (8000, 16000)


def crc32(data):
    return zlib.crc32(data) & 0xFFFFFFFF


def bytes_per_sample(sample_format):
    if sample_format not in (U8, U12_LE):
        raise ValueError('Unknown sample format')
    return 1 if sample_format == U8 else 2


def encode_samples(samples, sample_format):
    x = np.asarray(samples, dtype=float)
    if x.ndim != 1 or not np.isfinite(x).all():
        raise ValueError('Samples must be finite mono data')
    if sample_format == U8:
        return np.clip(np.rint(x * 128 + 128), 0, 255).astype('u1').tobytes()
    if sample_format == U12_LE:
        return np.clip(np.rint(x * 2048 + 2048), 0, 4095).astype('<u2').tobytes()
    raise ValueError('Unknown sample format')


@dataclass
class AudioFrame:
    rate: int
    sequence: int
    first_sample: int
    sample_format: int
    flags: int
    payload: bytes
    gap: bool = False
    samples: np.ndarray = field(init=False, repr=False)

    def __post_init__(self):
        if self.sample_format == U8:
            self.samples = (np.frombuffer(self.payload, dtype='u1').astype(float) - 128) / 128
        else:
            code = np.frombuffer(self.payload, dtype='<u2')
            if np.any(code > 4095):
                raise ValueError('U12_LE high four bits must be zero')
            self.samples = (code.astype(float) - 2048) / 2048


def encode_frame(samples, rate=8000, sequence=0, first_sample=0,
                 sample_format=U8, flags=0):
    payload = encode_samples(samples, sample_format)
    count = len(payload) // bytes_per_sample(sample_format)
    if rate not in RATES or not 1 <= count <= MAX_SAMPLES or flags & ~7:
        raise ValueError('Invalid rate, sample count or flags')
    prefix = PREFIX.pack(MAGIC, VERSION, HEADER_SIZE, sample_format, flags,
                         rate, sequence & 0xFFFFFFFF, first_sample & 0xFFFFFFFF,
                         count, len(payload), 0)
    header = prefix + struct.pack('<I', crc32(prefix))
    return header + payload + struct.pack('<I', crc32(header + payload))


def wire_bytes_per_second(rate, sample_format, count=256):
    return rate / count * (HEADER_SIZE + count * bytes_per_sample(sample_format) + 4)


class FrameParser:
    def __init__(self):
        self.buffer = bytearray()
        self.stats = dict(valid=0, crc_errors=0, header_errors=0, invalid_payloads=0,
                          sync_bytes=0, lost_frames=0, lost_samples=0,
                          duplicates=0, out_of_order=0, discontinuities=0,
                          header_crc_passed=0, header_crc_errors=0,
                          frame_crc_passed=0, truncated_frames=0,
                          delivered_frames=0, valid_samples=0)
        self.last = None
        # Cache a checked header while waiting for its payload. Otherwise each
        # serial fragment would count the same header CRC as another success.
        self._pending_header = None

    @staticmethod
    def _header(header):
        if crc32(header[:28]) != struct.unpack_from('<I', header, 28)[0]:
            raise ValueError('Header CRC')
        magic, version, size, fmt, flags, rate, seq, first, count, length, reserved = PREFIX.unpack(header[:28])
        if (magic != MAGIC or version != VERSION or size != HEADER_SIZE or
            fmt not in (U8, U12_LE) or flags & ~7 or rate not in RATES or
            not 1 <= count <= MAX_SAMPLES or reserved or
            length != count * bytes_per_sample(fmt)):
            raise ValueError('Invalid header fields')
        return fmt, flags, rate, seq, first, length

    def feed(self, data):
        result = []
        # Bound memory even if callers hand us a huge noise block.
        view = memoryview(data)
        for offset in range(0, len(view), 4096):
            self.buffer.extend(view[offset:offset+4096])
            result.extend(self._drain())
        return result

    def _drain(self):
        result = []
        while True:
            at = self.buffer.find(MAGIC)
            if at < 0:
                drop = max(0, len(self.buffer) - 3)
                self.stats['sync_bytes'] += drop
                del self.buffer[:drop]
                self._pending_header = None
                break
            if at:
                self.stats['sync_bytes'] += at
                del self.buffer[:at]
                self._pending_header = None
            if len(self.buffer) < HEADER_SIZE:
                break
            if self._pending_header is None:
                header = self.buffer[:HEADER_SIZE]
                if crc32(header[:28]) != struct.unpack_from('<I', header, 28)[0]:
                    self.stats['header_errors'] += 1
                    self.stats['header_crc_errors'] += 1
                    del self.buffer[0]
                    continue
                self.stats['header_crc_passed'] += 1
                try:
                    self._pending_header = self._header(header)
                except ValueError:
                    self.stats['header_errors'] += 1
                    del self.buffer[0]
                    continue
            fmt, flags, rate, seq, first, length = self._pending_header
            total = HEADER_SIZE + length + 4
            if len(self.buffer) < total:
                # A CRC-valid complete successor can recover a truncated frame.
                successor = self.buffer.find(MAGIC, 4)
                recovered = False
                while successor >= 0 and len(self.buffer) - successor >= HEADER_SIZE:
                    try:
                        next_length = self._header(self.buffer[successor:successor+HEADER_SIZE])[-1]
                        end = successor + HEADER_SIZE + next_length
                        if (len(self.buffer) >= end + 4 and
                            crc32(self.buffer[successor:end]) == struct.unpack_from('<I', self.buffer, end)[0]):
                            # There is no complete frame to CRC-check here.
                            # Count a confirmed truncation separately from CRC
                            # failures; an ordinary pending tail counts neither.
                            self.stats['truncated_frames'] += 1
                            self.stats['sync_bytes'] += successor
                            del self.buffer[:successor]
                            self._pending_header = None
                            recovered = True
                            break
                    except ValueError:
                        pass
                    successor = self.buffer.find(MAGIC, successor + 1)
                if recovered:
                    continue
                break
            if crc32(self.buffer[:total-4]) != struct.unpack_from('<I', self.buffer, total-4)[0]:
                self.stats['crc_errors'] += 1
                del self.buffer[0]
                self._pending_header = None
                continue
            self.stats['frame_crc_passed'] += 1
            payload = bytes(self.buffer[HEADER_SIZE:total-4])
            del self.buffer[:total]
            self._pending_header = None
            try:
                frame = AudioFrame(rate, seq, first, fmt, flags, payload)
            except ValueError:
                self.stats['invalid_payloads'] += 1
                continue
            self.stats['valid'] += 1
            reset = bool(flags & RESET)
            gap = bool(flags & (RESET | DISCONTINUITY))
            if self.last is not None and not reset:
                previous_seq, expected_first, previous_rate, previous_fmt, simulated = self.last
                delta = (seq - previous_seq) & 0xFFFFFFFF
                if delta == 0:
                    self.stats['duplicates'] += 1
                    continue
                if delta >= 0x80000000:
                    self.stats['out_of_order'] += 1
                    continue
                if delta > 1:
                    self.stats['lost_frames'] += delta - 1
                    gap = True
                missing = (first - expected_first) & 0xFFFFFFFF
                if missing:
                    if missing < 0x80000000:
                        self.stats['lost_samples'] += missing
                    gap = True
                if (rate, fmt, flags & SIMULATED) != (previous_rate, previous_fmt, simulated):
                    gap = True
            if gap and self.last is not None:
                self.stats['discontinuities'] += 1
            frame.gap = gap
            self.last = (seq, (first + len(frame.samples)) & 0xFFFFFFFF,
                         rate, fmt, flags & SIMULATED)
            self.stats['delivered_frames'] += 1
            self.stats['valid_samples'] += len(frame.samples)
            result.append(frame)
        return result
