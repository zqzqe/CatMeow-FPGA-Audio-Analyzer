"""Actual Tk display of XADC-model UART replay; no live serial/hardware claim."""
import json
from pathlib import Path
import time
import tkinter as tk
import traceback
from main import App,MODES,APP_DIR
from session import save_session,save_features,save_samples_csv


def run():
    root=tk.Tk();app=App(root)
    result=dict(passed=False,tests=[],callback_errors=[],scope='SIMULATION ONLY: AMD XADC-model UART data via serial test double; COM6 untouched')
    root.report_callback_exception=lambda kind,value,tb:result['callback_errors'].append(str(value))
    started=time.monotonic()

    def begin(hz):
        wire=(APP_DIR.parent/'reports'/f'SIMULATION_uart_{hz}.bin').read_bytes()
        class Replay:
            def __init__(self):self.position=0
            def open(self,*args):pass
            def close(self):pass
            def read(self):
                out=wire[self.position:self.position+113];self.position+=len(out);return out
        app.mode.set(MODES['audio']);app.switch_mode()
        app.port.set('SIMULATION_REPLAY');app.start(serial_factory=Replay)
        root.after(1000,lambda:verify(hz))

    def verify(hz):
        try:
            assert app.worker.snapshot()['valid']==16
            assert app.session.rate==8000
            assert '仿真/回放' in app.origin.get()
            assert all('非实板' in s.source for s in app.session.segments)
            assert len(app.wave_line.get_ydata())==4096
            assert abs(app.session.latest['dominant_hz']-hz)<8
            assert app.session.latest['peak']>0
            assert '峰值' in app.metrics.get()
            assert app.draw_count>1
            app.figure.suptitle(f'仿真验证：AMD XADC → UART → Python（{hz} Hz；非实板）')
            app.figure.savefig(APP_DIR/'reports'/f'SIMULATION_gui_{hz}.png')
            app.stop()
            stem=APP_DIR/'reports'/f'SIMULATION_GUI_{hz}_{time.time_ns()}'
            outputs=save_session(app.session,stem.with_suffix('.wav'),app.stats)
            save_features(app.session.features,stem.with_suffix('.features.csv'))
            assert save_samples_csv(app.session,stem.with_suffix('.samples.csv'))==4096
            assert '非实板' in outputs[-1].read_text(encoding='utf-8')
            result['tests'].append(dict(hz=hz,frames=16,gui_peak_bin_hz=app.session.latest['dominant_hz'],
                                        peak=app.session.latest['peak'],source_label=app.origin.get(),
                                        wav_and_csv_saved=True,waveform_samples=4096))
            if hz==440:begin(1000)
            else:finish()
        except Exception as exc:finish(exc)

    def finish(error=None):
        if error:result.update(error=repr(error),traceback=traceback.format_exc())
        result['passed']=error is None and not result['callback_errors']
        (APP_DIR/'reports'/'gui_microphone_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False,indent=2),flush=True);app.close()

    begin(440);root.mainloop()
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(run())
