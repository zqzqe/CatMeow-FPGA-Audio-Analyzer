"""Future dataset/model contracts. No model loading or classification is done."""
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, Mapping
import json


@dataclass(frozen=True)
class LabeledAudio:
    path: Path
    label: str
    subject_id: str
    split: str


def read_labeled_manifest(path):
    manifest = Path(path)
    rows = json.loads(manifest.read_text(encoding='utf-8'))
    if not isinstance(rows, list):
        raise ValueError('Manifest must be a JSON list')
    result = []
    for row in rows:
        audio = (manifest.parent / row['wav']).resolve()
        if not audio.is_file() or not str(row.get('label', '')).strip():
            raise ValueError('Each record needs an existing WAV and a real label')
        result.append(LabeledAudio(audio, row['label'], row.get('subject_id', ''), row.get('split', 'unassigned')))
    return result


class ClassifierAdapter(Protocol):
    """Implement externally after labeled-data validation; not called by V0.3."""
    def predict(self, features: Mapping[str, float]) -> Mapping[str, object]: ...


CLASSIFIER_STATUS = '尚未接入分类模型；没有训练结果或情绪识别准确率。'
