"""Bounded recording, feature cache and discontinuity-aware WAV persistence."""
import csv
from dataclasses import dataclass, field
from collections import deque
from datetime import datetime
import json
from pathlib import Path
import wave
import numpy as np
from features import FeatureStream


class RecordingLimit(Exception):
    pass


@dataclass
class Segment:
    rate: int
    source: str
    sample_format: int
    first_sample: int
    chunks: list = field(default_factory=list)
    count: int = 0


class AudioSession:
    def __init__(self, max_seconds=120):
        self.max_seconds = max_seconds
        self.seconds = 0.0
        self.segments = []
        self.features = deque(maxlen=2048)
        self.waveform = np.empty(0)
        self.analyzer = None
        self.latest = None
        self.expected_sample = None
        self.discontinuities = 0
        self.last_sequence = None
        self.created_at = datetime.now().isoformat(timespec='seconds')

    def ingest(self, frame, source):
        if self.seconds + len(frame.samples) / frame.rate > self.max_seconds + 1e-9:
            raise RecordingLimit(f'达到 {self.max_seconds} 秒录制上限；请保存数据')
        current = self.segments[-1] if self.segments else None
        split = (current is None or frame.gap or
                 (current.rate, current.source, current.sample_format) !=
                 (frame.rate, source, frame.sample_format) or
                 self.expected_sample != frame.first_sample)
        if split:
            if current is not None:
                self.discontinuities += 1
            current = Segment(frame.rate, source, frame.sample_format, frame.first_sample)
            self.segments.append(current)
            self.analyzer = FeatureStream(frame.rate)
            self.waveform = np.empty(0)
            self.latest = None
        samples = np.array(frame.samples, copy=True)
        current.chunks.append(samples)
        current.count += len(samples)
        self.seconds += len(samples) / frame.rate
        self.expected_sample = (frame.first_sample + len(samples)) & 0xFFFFFFFF
        self.last_sequence = frame.sequence
        self.waveform = np.concatenate((self.waveform, samples))[-4096:]
        for result in self.analyzer.feed(samples):
            result.update(segment=len(self.segments), source=source, sample_rate=frame.rate)
            self.features.append(result)
            self.latest = result

    @property
    def rate(self):
        return self.segments[-1].rate if self.segments else None


def write_wav(path, samples, rate):
    pcm = np.clip(np.rint(np.asarray(samples) * 32768), -32768, 32767).astype('<i2')
    with wave.open(str(path), 'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(rate)
        output.writeframes(pcm.tobytes())


def read_wav(path, max_seconds=120):
    with wave.open(str(path), 'rb') as input_file:
        channels, width, rate, count = (input_file.getnchannels(), input_file.getsampwidth(),
                                        input_file.getframerate(), input_file.getnframes())
        if channels not in (1, 2) or width not in (1, 2) or not 1000 <= rate <= 48000:
            raise ValueError('仅支持 1/2 声道、PCM 8/16 位、1–48 kHz WAV')
        if count == 0 or count / rate > max_seconds:
            raise ValueError(f'WAV 必须非空且不超过 {max_seconds} 秒')
        raw = input_file.readframes(count)
        if len(raw) != count * channels * width:
            raise ValueError('WAV 数据不完整')
    if width == 1:
        samples = (np.frombuffer(raw, dtype='u1').astype(float) - 128) / 128
    else:
        samples = np.frombuffer(raw, dtype='<i2').astype(float) / 32768
    if channels == 2:
        samples = samples.reshape(-1, 2).mean(axis=1)
    return samples, rate


def save_session(session, path, transport_stats=None):
    if not session.segments:
        raise ValueError('尚无完整有效音频数据可保存')
    path = Path(path).with_suffix('.wav')
    paths = [path if len(session.segments) == 1 else
             path.with_name(f'{path.stem}_part{i:03d}.wav')
             for i in range(1, len(session.segments)+1)]
    manifest_path = path.with_suffix('.session.json')
    # File dialogs handle the single selected WAV overwrite; sidecars/parts must
    # never silently overwrite unrelated pre-existing recordings.
    if manifest_path.exists() or (len(paths) > 1 and any(p.exists() for p in paths)):
        raise FileExistsError('同名分段文件或会话说明已存在，请换一个文件名')
    manifest = dict(version='0.3', created_at=session.created_at,
                    saved_at=datetime.now().isoformat(timespec='seconds'),
                    seconds=session.seconds, discontinuities=session.discontinuities,
                    transport_stats=transport_stats or {}, segments=[],
                    classifier='not connected', gap_policy='separate WAV segments; no fabricated samples')
    for segment, output in zip(session.segments, paths):
        write_wav(output, np.concatenate(segment.chunks), segment.rate)
        manifest['segments'].append(dict(file=output.name, source=segment.source,
                                         rate=segment.rate, count=segment.count,
                                         first_sample=segment.first_sample,
                                         wire_sample_format=segment.sample_format,
                                         wav_encoding='PCM16 mono normalized full scale'))
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return paths + [manifest_path]


def save_features(features, path):
    rows = list(features)
    if not rows:
        raise ValueError('尚无完整分析帧')
    with Path(path).open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_samples_csv(session, path):
    """Export actual retained samples, preserving segment and source provenance."""
    if not session.segments:
        raise ValueError('尚无有效音频采样')
    count = 0
    with Path(path).open('x', newline='', encoding='utf-8-sig') as output:
        writer = csv.writer(output)
        writer.writerow(['segment', 'source', 'sample_rate', 'sample_index',
                         'segment_time_seconds', 'normalized_sample'])
        for index, segment in enumerate(session.segments, 1):
            position = 0
            for chunk in segment.chunks:
                for value in chunk:
                    writer.writerow([index, segment.source, segment.rate,
                                     (segment.first_sample+position) & 0xFFFFFFFF,
                                     position/segment.rate, float(value)])
                    position += 1
                    count += 1
    return count
