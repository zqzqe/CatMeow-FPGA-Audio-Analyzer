# CAUD/1 音频二进制协议（V0.3 实际实现）

状态：Python 编解码器已实现；Verilog 必须遵守本文件，不兼容温度版 TEMP_RAW 文本。UART 为 8N1、无流控，默认 115200。每个方向目前仅定义 FPGA→PC 音频，不含串口命令。

## 线格式

一帧 = **32 字节头 + payload_length 字节 PCM + 4 字节帧 CRC**。所有多字节整数及 CRC 在串线上均为小端；字节内 UART 为 LSB-first。头前 28 字节的 Python struct 格式是 `<4sBBBBIIIHHI`。

| 偏移 | 字节数 | 字段 | v1 规则 |
|---:|---:|---|---|
| 0 | 4 | magic | ASCII `CAUD`，hex `43 41 55 44` |
| 4 | 1 | version | 1 |
| 5 | 1 | header_size | 32（0x20） |
| 6 | 1 | sample_format | 1=U8；2=U12_LE |
| 7 | 1 | flags | bit0=SIMULATED，bit1=RESET，bit2=DISCONTINUITY；其余必须为0 |
| 8 | 4 | sample_rate | 8000 或 16000，单位 sample/s |
| 12 | 4 | sequence | 每帧加1，uint32 回绕 |
| 16 | 4 | first_sample | 本帧首采样编号，uint32 回绕 |
| 20 | 2 | sample_count | 1–1024；常规值256 |
| 22 | 2 | payload_length | U8=count，U12_LE=2×count |
| 24 | 4 | reserved | 0 |
| 28 | 4 | header_crc32 | 对偏移0–27的28字节计算 CRC32 |
| 32 | N | payload | 单声道 PCM，无压缩 |
| 32+N | 4 | frame_crc32 | 对偏移0到31+N计算，包含整个32字节头及payload，不包含最后本CRC |

首帧置 RESET，重启采集或重新配置也必须置 RESET（并建议 sequence/first_sample 从0开始）。连续帧通常只保留来源标志。FPGA 内部数字波形发生器属于测试数据，**必须始终置 SIMULATED**，不能标为真实麦克风。

U8：无符号8位，128为零偏置，归一化 `x=(code-128)/128`。从单极性12位 ADC code 转换到8位时，可采用 `u8=adc_code>>4`。U12_LE：每点无符号16位小端，低12位存放0–4095 ADC code，高4位必须为0；归一化 `(code-2048)/2048`。这是容器定义，与温度版完整16位DRP返回字不同。实际音频 DC 偏置仍需去除。

## CRC 精确定义

CRC-32/ISO-HDLC（与 Python `zlib.crc32(bytes) & 0xFFFFFFFF` 相同）：宽32，常规多项式0x04C11DB7，逐位反射实现多项式 **0xEDB88320**，init=0xFFFFFFFF，refin/refout=true，xorout=0xFFFFFFFF。每字节从bit0开始处理；处理最后字节后对内部寄存器按位取反，按低字节先发。

标准向量 ASCII `123456789` → CRC **0xCBF43926**，线上字节 `26 39 F4 CB`。不要把 CRC 内部未取反状态直接当成线上CRC。

接收器先验证 header CRC，再信任长度；字段合法后等待完整payload并验证frame CRC。没有CRC的帧不交给音频分析。

## 带宽预算

256 点U8：32+256+4 = **292 B/帧**，8000/256=31.25帧/s，**9125 B/s**；含8N1起止位为91250 bit/s，占115200约 **79.21%**。单帧UART线时间约25.347 ms，采样块时间32 ms，剩约6.65 ms用于帧间空隙/逻辑开销。

256 点U12_LE：548 B/帧，16 kS/s 为 **34250 B/s** /342500 bit/s；115200不能持续，460800占约74.33%，需实测USB串口桥吞吐。V0.3模拟器限制线预算不超过85%。GUI显示频率不等于采样率。

## 解析、丢包与恢复

- `FrameParser.feed(bytes)` 保留半帧，支持逐字节、拆包、粘包及头前噪声。
- header/字段或frame CRC失败时逐字节重找magic；长度被1024点上限约束。
- 若当前帧被截断，而缓存后面存在另一条头和整帧CRC均有效的完整帧，可以丢弃截断前缀后恢复。CRC用于误码检测，不是认证；不保证抵抗恶意构造的嵌套帧。
- 无magic时只保留3个尾字节，避免噪声无限积累；最大合法帧2084B。
- sequence跳跃统计丢帧；首样本编号跳跃统计丢样。重复帧/倒序帧不重复分析，uint32自然回绕可接受。RESET启用新会话，防止重启后永远被当作倒序。
- 采样率、格式、来源变化及丢样都切开分析分段。GUI不会用零值伪造缺失音频，WAV另存多个part并用session JSON说明。
- 主机事件队列最多128项；队列丢弃有计数，session仍核对采样编号识别缺口。FIFO/队列只能吸收短期抖动，不能补偿长期带宽不足。

## 固定 292 字节实板数据回归（2026-11-02）

本次实板采集文件遵循上表既有格式：format=1、flags=1、sample_count=256、payload_length=256、reserved=0。头为0–31，U8载荷32–287，帧CRC288–291。采样率读取头内uint32，不能使用GUI中的“模拟采样率”替代。没有新增或改变FPGA协议。

CRC统计口径：`header_crc_errors` 为头CRC失败次数；`crc_errors` 为完整帧CRC失败次数；GUI“CRC错误”为二者之和。`header_errors` 包括头CRC和字段非法，不能再与前两者重复相加。`truncated_frames` 只统计被完整有效后继帧证实并跳过的截断帧。尚未收到足够字节的头或帧继续等待，普通末尾半帧不累计CRC错误或截断错误。

`header_crc_passed` 按每个已检查头计数，缓存相同头以避免拆包重复计数；可能包括尚未完整收齐载荷的尾帧头。`frame_crc_passed` 为完整帧CRC通过次数；`valid` 为CRC、字段和载荷格式合法的帧数（包含随后被去重的帧），`delivered_frames` 和 `valid_samples` 为去除重复/倒序后实际交给分析的数据。GUI单独显示重复、倒序、丢帧、丢采样和队列丢弃。

桌面文件425个完整帧的头CRC通过425次，另有第426个有效头和未完整载荷，共123字节待接收，因此流式`header_crc_passed=426`、`frame_crc_passed=425`；这不是多出一个完整帧。

## 可执行参考

实现：`audio_protocol.py`，自动测试：`tests/test_v03.py`。发送端先用标准CRC向量验证实现，再用Python真实解析器解析仿真输出。规范测试帧向量位于 `reports/protocol_vector.json`，字段、hex和CRC均由同版本编码器导出；它还需与独立UART testbench端到端核对。
